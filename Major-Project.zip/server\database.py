"""
Database connection and session management
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, Settings, DEFAULT_SETTINGS

DATABASE_URL = "sqlite:///./power_management.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """Initialize database tables and default settings"""
    Base.metadata.create_all(bind=engine)
    
    # Insert default settings if not exists
    db = SessionLocal()
    try:
        for key, config in DEFAULT_SETTINGS.items():
            existing = db.query(Settings).filter(Settings.key == key).first()
            if not existing:
                setting = Settings(
                    key=key,
                    value=config["value"],
                    description=config["description"]
                )
                db.add(setting)
        db.commit()
    finally:
        db.close()


def get_db():
    """Dependency for FastAPI routes"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
