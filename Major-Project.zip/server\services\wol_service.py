"""
Wake-on-LAN service for remotely waking powered-off devices
"""
from wakeonlan import send_magic_packet
import socket
import struct


def wake_device(mac_address: str, broadcast_ip: str = "255.255.255.255", port: int = 9) -> bool:
    """
    Send a Wake-on-LAN magic packet to wake a device
    
    Args:
        mac_address: MAC address of the target device (e.g., "AA:BB:CC:DD:EE:FF")
        broadcast_ip: Broadcast address for the network
        port: UDP port to send the packet (default: 9)
    
    Returns:
        bool: True if packet sent successfully
    """
    try:
        # Normalize MAC address format
        mac = mac_address.replace(":", "").replace("-", "").upper()
        
        if len(mac) != 12:
            raise ValueError(f"Invalid MAC address: {mac_address}")
        
        # Use the wakeonlan library
        send_magic_packet(mac)
        return True
        
    except Exception as e:
        print(f"WOL Error: {e}")
        return False


def wake_multiple_devices(mac_addresses: list[str]) -> dict:
    """
    Send WOL packets to multiple devices
    
    Returns:
        dict: {mac_address: success_bool}
    """
    results = {}
    for mac in mac_addresses:
        results[mac] = wake_device(mac)
    return results


def create_magic_packet(mac_address: str) -> bytes:
    """
    Create a Wake-on-LAN magic packet manually
    
    Magic packet format:
    - 6 bytes of 0xFF
    - 16 repetitions of the target MAC address
    """
    mac = mac_address.replace(":", "").replace("-", "")
    if len(mac) != 12:
        raise ValueError(f"Invalid MAC address: {mac_address}")
    
    # Convert MAC to bytes
    mac_bytes = bytes.fromhex(mac)
    
    # Create magic packet: 6 * 0xFF + 16 * MAC
    magic_packet = b'\xff' * 6 + mac_bytes * 16
    
    return magic_packet
