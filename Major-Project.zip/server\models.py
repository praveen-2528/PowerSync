"""
Database models for Smart Power Management System
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()


class DeviceStatus(str, enum.Enum):
    ACTIVE = "active"           # Input detected within 60s
    PASSIVE_IDLE = "passive"    # No input 5-15 mins
    DEEP_IDLE = "deep_idle"     # No input > 20 mins
    OFFLINE = "offline"         # No heartbeat > 2 mins


class Device(Base):
    """Registered lab computer"""
    __tablename__ = "devices"
    
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String(100), unique=True, index=True)  # Unique identifier
    hostname = Column(String(255))
    ip_address = Column(String(45))
    mac_address = Column(String(17))  # For Wake-on-LAN
    
    # Hardware specs
    os_name = Column(String(100))
    os_version = Column(String(50))
    cpu_model = Column(String(200))
    ram_total_gb = Column(Float)
    
    # Status tracking
    status = Column(String(20), default=DeviceStatus.OFFLINE.value)
    last_heartbeat = Column(DateTime)
    idle_seconds = Column(Integer, default=0)
    cpu_usage = Column(Float, default=0.0)
    system_type = Column(String(20), default="lab")  # lab, admin, server, personal, network
    
    # Power stats
    total_uptime_minutes = Column(Integer, default=0)
    total_idle_minutes = Column(Integer, default=0)
    total_powered_off_minutes = Column(Integer, default=0)
    
    # Relationships
    heartbeats = relationship("Heartbeat", back_populates="device")
    power_events = relationship("PowerEvent", back_populates="device")
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Heartbeat(Base):
    """Activity log from agent heartbeats"""
    __tablename__ = "heartbeats"
    
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"))
    
    idle_seconds = Column(Integer)
    cpu_usage = Column(Float)
    ram_usage = Column(Float)
    status = Column(String(20))
    
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    device = relationship("Device", back_populates="heartbeats")


class PowerEvent(Base):
    """Shutdown/Wake events for analytics"""
    __tablename__ = "power_events"
    
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"))
    
    event_type = Column(String(20))  # SHUTDOWN, SLEEP, WAKE, WOL
    triggered_by = Column(String(50))  # auto, manual, user
    
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    device = relationship("Device", back_populates="power_events")


class NetworkSwitch(Base):
    """Network switch/router dependency mapping"""
    __tablename__ = "network_switches"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100))
    location = Column(String(200))  # e.g., "Lab A"
    
    # IoT Smart Plug control (optional)
    smart_plug_ip = Column(String(45), nullable=True)
    smart_plug_type = Column(String(50), nullable=True)
    
    is_powered = Column(Boolean, default=True)
    
    # List of device IDs connected to this switch (JSON string)
    connected_device_ids = Column(String(1000))
    
    created_at = Column(DateTime, default=datetime.utcnow)


class Settings(Base):
    """System configuration settings"""
    __tablename__ = "settings"
    
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(100), unique=True)
    value = Column(String(500))
    description = Column(String(500))
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# Default settings to be inserted
DEFAULT_SETTINGS = {
    "idle_threshold_passive": {"value": "60", "description": "Seconds before marking as passive idle (1 min)"},
    "idle_threshold_deep": {"value": "120", "description": "Seconds before marking as deep idle (2 mins)"},
    "working_hours_start": {"value": "09:00", "description": "Start of working hours (24h format)"},
    "working_hours_end": {"value": "17:00", "description": "End of working hours (24h format)"},
    "after_hours_idle_threshold": {"value": "180", "description": "Idle seconds before shutdown after hours (3 mins MAX)"},
    "working_hours_idle_threshold": {"value": "180", "description": "Idle seconds before sleep during hours (3 mins MAX)"},
    "grace_period_seconds": {"value": "30", "description": "Warning popup duration before action"},
    "heartbeat_timeout_seconds": {"value": "120", "description": "Seconds without heartbeat to mark offline"},
    "avg_pc_wattage": {"value": "200", "description": "Average PC power consumption in watts"},
    "cost_per_kwh": {"value": "8.0", "description": "Electricity cost per kWh in rupees"},
    "carbon_intensity": {"value": "0.82", "description": "kg CO2 per kWh (India grid average)"},
}
