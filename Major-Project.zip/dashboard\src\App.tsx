import { useState, useEffect } from 'react'
import {
    Monitor, Power, Sun, Moon, Zap, Wifi, WifiOff,
    Settings, BarChart3, Activity, X, RefreshCw,
    PowerOff, Play, AlertTriangle, TrendingUp, Leaf, DollarSign, Save
} from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'
import './App.css'

const API_URL = 'http://localhost:8000'

const statusColors = {
    active: '#22c55e',
    passive: '#eab308',
    deep_idle: '#f97316',
    offline: '#ef4444'
}

const statusLabels = {
    active: 'Active',
    passive: 'Idle',
    deep_idle: 'Deep Idle',
    offline: 'Offline'
}

function App() {
    const [devices, setDevices] = useState([])
    const [analytics, setAnalytics] = useState(null)
    const [settings, setSettings] = useState([])
    const [selectedDevice, setSelectedDevice] = useState(null)
    const [deviceDetail, setDeviceDetail] = useState(null)
    const [loading, setLoading] = useState(true)
    const [activeTab, setActiveTab] = useState('dashboard')
    const [savingSettings, setSavingSettings] = useState(false)

    const fetchData = async () => {
        try {
            const [devicesRes, analyticsRes] = await Promise.all([
                fetch(`${API_URL}/api/devices`),
                fetch(`${API_URL}/api/analytics`)
            ])
            if (devicesRes.ok) {
                const data = await devicesRes.json()
                setDevices(data.devices)
            }
            if (analyticsRes.ok) {
                const data = await analyticsRes.json()
                setAnalytics(data)
            }
        } catch (error) {
            console.error('Failed to fetch data:', error)
        } finally {
            setLoading(false)
        }
    }

    const fetchSettings = async () => {
        try {
            const res = await fetch(`${API_URL}/api/settings`)
            if (res.ok) {
                const data = await res.json()
                setSettings(data.settings)
            }
        } catch (error) {
            console.error('Failed to fetch settings:', error)
        }
    }

    const updateSetting = async (key, value) => {
        setSavingSettings(true)
        try {
            await fetch(`${API_URL}/api/settings`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ key, value })
            })
            await fetchSettings()
        } catch (error) {
            console.error('Failed to update setting:', error)
        } finally {
            setSavingSettings(false)
        }
    }

    const fetchDeviceDetail = async (deviceId) => {
        try {
            const res = await fetch(`${API_URL}/api/devices/${deviceId}`)
            if (res.ok) {
                const data = await res.json()
                setDeviceDetail(data)
            }
        } catch (error) {
            console.error('Failed to fetch device detail:', error)
        }
    }

    const sendCommand = async (deviceId, command, message = '') => {
        try {
            const res = await fetch(`${API_URL}/api/devices/${deviceId}/command`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ command, message })
            })
            if (res.ok) {
                fetchData()
            }
        } catch (error) {
            console.error('Failed to send command:', error)
        }
    }

    const wakeDevice = async (deviceId) => {
        try {
            await fetch(`${API_URL}/api/devices/${deviceId}/wake`, { method: 'POST' })
        } catch (error) {
            console.error('Failed to wake device:', error)
        }
    }

    useEffect(() => {
        fetchData()
        fetchSettings()
        const interval = setInterval(fetchData, 5000)
        return () => clearInterval(interval)
    }, [])

    useEffect(() => {
        if (selectedDevice) {
            fetchDeviceDetail(selectedDevice)
        }
    }, [selectedDevice])

    const formatIdleTime = (seconds) => {
        if (seconds < 60) return `${seconds}s`
        if (seconds < 3600) return `${Math.floor(seconds / 60)}m`
        return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`
    }

    const getSetting = (key) => {
        const setting = settings.find(s => s.key === key)
        return setting ? setting.value : ''
    }

    // Render Analytics Tab
    const renderAnalytics = () => {
        // Generate sample weekly data based on current analytics
        const weeklyData = [
            { day: 'Mon', energy: (analytics?.total_energy_saved_kwh || 0) * 0.12, cost: (analytics?.total_cost_saved_rupees || 0) * 0.12, co2: (analytics?.total_co2_reduced_kg || 0) * 0.12 },
            { day: 'Tue', energy: (analytics?.total_energy_saved_kwh || 0) * 0.15, cost: (analytics?.total_cost_saved_rupees || 0) * 0.15, co2: (analytics?.total_co2_reduced_kg || 0) * 0.15 },
            { day: 'Wed', energy: (analytics?.total_energy_saved_kwh || 0) * 0.18, cost: (analytics?.total_cost_saved_rupees || 0) * 0.18, co2: (analytics?.total_co2_reduced_kg || 0) * 0.18 },
            { day: 'Thu', energy: (analytics?.total_energy_saved_kwh || 0) * 0.14, cost: (analytics?.total_cost_saved_rupees || 0) * 0.14, co2: (analytics?.total_co2_reduced_kg || 0) * 0.14 },
            { day: 'Fri', energy: (analytics?.total_energy_saved_kwh || 0) * 0.16, cost: (analytics?.total_cost_saved_rupees || 0) * 0.16, co2: (analytics?.total_co2_reduced_kg || 0) * 0.16 },
            { day: 'Sat', energy: (analytics?.total_energy_saved_kwh || 0) * 0.13, cost: (analytics?.total_cost_saved_rupees || 0) * 0.13, co2: (analytics?.total_co2_reduced_kg || 0) * 0.13 },
            { day: 'Sun', energy: (analytics?.total_energy_saved_kwh || 0) * 0.12, cost: (analytics?.total_cost_saved_rupees || 0) * 0.12, co2: (analytics?.total_co2_reduced_kg || 0) * 0.12 },
        ]

        return (
            <div className="analytics-view">
                <h1 style={{ marginBottom: 24 }}>📊 Analytics & Sustainability</h1>

                {/* Main metrics */}
                <div className="analytics-grid">
                    <div className="analytics-card green">
                        <div className="analytics-icon"><Zap size={32} /></div>
                        <div className="analytics-content">
                            <div className="analytics-value">{analytics?.total_energy_saved_kwh || 0} kWh</div>
                            <div className="analytics-label">Total Energy Saved</div>
                        </div>
                    </div>
                    <div className="analytics-card purple">
                        <div className="analytics-icon"><DollarSign size={32} /></div>
                        <div className="analytics-content">
                            <div className="analytics-value">₹{analytics?.total_cost_saved_rupees || 0}</div>
                            <div className="analytics-label">Total Money Saved</div>
                        </div>
                    </div>
                    <div className="analytics-card yellow">
                        <div className="analytics-icon"><Leaf size={32} /></div>
                        <div className="analytics-content">
                            <div className="analytics-value">{analytics?.total_co2_reduced_kg || 0} kg</div>
                            <div className="analytics-label">CO₂ Emissions Reduced</div>
                        </div>
                    </div>
                </div>

                {/* Today vs This Month */}
                <div className="stats-grid" style={{ marginTop: 24 }}>
                    <div className="stat-card savings">
                        <div className="stat-label"><TrendingUp size={16} /> Today's Savings</div>
                        <div className="stat-value savings">₹{analytics?.today_cost_saved_rupees || 0}</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                            {analytics?.today_energy_saved_kwh || 0} kWh saved
                        </div>
                    </div>
                    <div className="stat-card savings">
                        <div className="stat-label"><BarChart3 size={16} /> This Month</div>
                        <div className="stat-value savings">₹{analytics?.this_month_cost_saved_rupees || 0}</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                            {analytics?.this_month_energy_saved_kwh || 0} kWh saved
                        </div>
                    </div>
                    <div className="stat-card active">
                        <div className="stat-label"><Monitor size={16} /> Total Devices</div>
                        <div className="stat-value active">{analytics?.total_devices || 0}</div>
                    </div>
                </div>

                {/* Charts Row */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, marginTop: 24 }}>
                    {/* Weekly Savings Trend - Bar Chart */}
                    <div className="glass-card" style={{ padding: 24 }}>
                        <h3 style={{ marginBottom: 20 }}>📈 Weekly Savings Trend</h3>
                        <div style={{ height: 250 }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={weeklyData}>
                                    <XAxis dataKey="day" stroke="var(--text-muted)" />
                                    <YAxis stroke="var(--text-muted)" />
                                    <Tooltip
                                        contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8 }}
                                        formatter={(value: number) => [`₹${value.toFixed(2)}`, 'Cost Saved']}
                                    />
                                    <Bar dataKey="cost" fill="#7c3aed" radius={[4, 4, 0, 0]} />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    {/* Energy & CO2 Trends - Area Chart */}
                    <div className="glass-card" style={{ padding: 24 }}>
                        <h3 style={{ marginBottom: 20 }}>⚡ Energy & CO₂ Reduction</h3>
                        <div style={{ height: 250 }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={weeklyData}>
                                    <defs>
                                        <linearGradient id="energyGrad" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#22c55e" stopOpacity={0.4} />
                                            <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                                        </linearGradient>
                                        <linearGradient id="co2Grad" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#eab308" stopOpacity={0.4} />
                                            <stop offset="95%" stopColor="#eab308" stopOpacity={0} />
                                        </linearGradient>
                                    </defs>
                                    <XAxis dataKey="day" stroke="var(--text-muted)" />
                                    <YAxis stroke="var(--text-muted)" />
                                    <Tooltip
                                        contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8 }}
                                    />
                                    <Area type="monotone" dataKey="energy" stroke="#22c55e" fill="url(#energyGrad)" strokeWidth={2} name="Energy (kWh)" />
                                    <Area type="monotone" dataKey="co2" stroke="#eab308" fill="url(#co2Grad)" strokeWidth={2} name="CO₂ (kg)" />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>

                {/* Device Status Distribution */}
                <div className="glass-card" style={{ marginTop: 24, padding: 24 }}>
                    <h3 style={{ marginBottom: 20 }}>🖥️ Device Status Distribution</h3>
                    <div style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'center' }}>
                        <div style={{ width: 220, height: 220 }}>
                            <ResponsiveContainer>
                                <PieChart>
                                    <Pie
                                        data={[
                                            { name: 'Active', value: analytics?.active_devices || 0, color: '#22c55e' },
                                            { name: 'Idle', value: analytics?.idle_devices || 0, color: '#eab308' },
                                            { name: 'Offline', value: analytics?.offline_devices || 0, color: '#ef4444' }
                                        ]}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={55}
                                        outerRadius={90}
                                        dataKey="value"
                                        label={({ name, value }) => value > 0 ? `${name}: ${value}` : ''}
                                    >
                                        {[
                                            { color: '#22c55e' },
                                            { color: '#eab308' },
                                            { color: '#ef4444' }
                                        ].map((entry, index) => (
                                            <Cell key={index} fill={entry.color} />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                        <div className="legend" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                            <div className="legend-item" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                <span className="dot" style={{ background: '#22c55e', width: 12, height: 12, borderRadius: '50%' }}></span>
                                <span>Active: {analytics?.active_devices || 0} devices</span>
                            </div>
                            <div className="legend-item" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                <span className="dot" style={{ background: '#eab308', width: 12, height: 12, borderRadius: '50%' }}></span>
                                <span>Idle: {analytics?.idle_devices || 0} devices</span>
                            </div>
                            <div className="legend-item" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                <span className="dot" style={{ background: '#ef4444', width: 12, height: 12, borderRadius: '50%' }}></span>
                                <span>Offline: {analytics?.offline_devices || 0} devices</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Savings Comparison Card */}
                <div className="glass-card" style={{ marginTop: 24, padding: 24 }}>
                    <h3 style={{ marginBottom: 20 }}>💰 Savings Comparison</h3>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
                        <div style={{ textAlign: 'center', padding: 20, background: 'rgba(34, 197, 94, 0.1)', borderRadius: 12 }}>
                            <div style={{ fontSize: '2rem', fontWeight: 700, color: '#22c55e' }}>
                                {analytics?.today_energy_saved_kwh || 0}
                            </div>
                            <div style={{ color: 'var(--text-muted)', marginTop: 4 }}>kWh Today</div>
                        </div>
                        <div style={{ textAlign: 'center', padding: 20, background: 'rgba(124, 58, 237, 0.1)', borderRadius: 12 }}>
                            <div style={{ fontSize: '2rem', fontWeight: 700, color: '#7c3aed' }}>
                                {analytics?.this_month_energy_saved_kwh || 0}
                            </div>
                            <div style={{ color: 'var(--text-muted)', marginTop: 4 }}>kWh This Month</div>
                        </div>
                        <div style={{ textAlign: 'center', padding: 20, background: 'rgba(234, 179, 8, 0.1)', borderRadius: 12 }}>
                            <div style={{ fontSize: '2rem', fontWeight: 700, color: '#eab308' }}>
                                {analytics?.total_energy_saved_kwh || 0}
                            </div>
                            <div style={{ color: 'var(--text-muted)', marginTop: 4 }}>kWh Total</div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    // Render Settings Tab
    const renderSettings = () => (
        <div className="settings-view">
            <h1 style={{ marginBottom: 24 }}>⚙️ System Settings</h1>

            <div className="settings-grid">
                {/* Working Hours */}
                <div className="settings-card">
                    <h3>🕐 Working Hours</h3>
                    <div className="settings-form">
                        <div className="form-group">
                            <label>Start Time</label>
                            <input
                                type="time"
                                value={getSetting('working_hours_start')}
                                onChange={(e) => updateSetting('working_hours_start', e.target.value)}
                            />
                        </div>
                        <div className="form-group">
                            <label>End Time</label>
                            <input
                                type="time"
                                value={getSetting('working_hours_end')}
                                onChange={(e) => updateSetting('working_hours_end', e.target.value)}
                            />
                        </div>
                    </div>
                </div>

                {/* Idle Thresholds */}
                <div className="settings-card">
                    <h3>⏱️ Idle Thresholds</h3>
                    <div className="settings-form">
                        <div className="form-group">
                            <label>Working Hours Threshold (seconds)</label>
                            <input
                                type="number"
                                value={getSetting('working_hours_idle_threshold')}
                                onChange={(e) => updateSetting('working_hours_idle_threshold', e.target.value)}
                                min="60"
                                max="1800"
                            />
                            <small>Sleep after this idle time during working hours</small>
                        </div>
                        <div className="form-group">
                            <label>After Hours Threshold (seconds)</label>
                            <input
                                type="number"
                                value={getSetting('after_hours_idle_threshold')}
                                onChange={(e) => updateSetting('after_hours_idle_threshold', e.target.value)}
                                min="60"
                                max="600"
                            />
                            <small>Shutdown after this idle time outside working hours</small>
                        </div>
                        <div className="form-group">
                            <label>Grace Period (seconds)</label>
                            <input
                                type="number"
                                value={getSetting('grace_period_seconds')}
                                onChange={(e) => updateSetting('grace_period_seconds', e.target.value)}
                                min="10"
                                max="120"
                            />
                            <small>Warning popup duration before action</small>
                        </div>
                    </div>
                </div>

                {/* Energy Settings */}
                <div className="settings-card">
                    <h3>⚡ Energy Calculation</h3>
                    <div className="settings-form">
                        <div className="form-group">
                            <label>Average PC Wattage (W)</label>
                            <input
                                type="number"
                                value={getSetting('avg_pc_wattage')}
                                onChange={(e) => updateSetting('avg_pc_wattage', e.target.value)}
                                min="50"
                                max="500"
                            />
                        </div>
                        <div className="form-group">
                            <label>Cost per kWh (₹)</label>
                            <input
                                type="number"
                                step="0.1"
                                value={getSetting('cost_per_kwh')}
                                onChange={(e) => updateSetting('cost_per_kwh', e.target.value)}
                            />
                        </div>
                        <div className="form-group">
                            <label>Carbon Intensity (kg CO₂/kWh)</label>
                            <input
                                type="number"
                                step="0.01"
                                value={getSetting('carbon_intensity')}
                                onChange={(e) => updateSetting('carbon_intensity', e.target.value)}
                            />
                        </div>
                    </div>
                </div>

                {/* Timeouts */}
                <div className="settings-card">
                    <h3>🔌 Connection Settings</h3>
                    <div className="settings-form">
                        <div className="form-group">
                            <label>Heartbeat Timeout (seconds)</label>
                            <input
                                type="number"
                                value={getSetting('heartbeat_timeout_seconds')}
                                onChange={(e) => updateSetting('heartbeat_timeout_seconds', e.target.value)}
                                min="60"
                                max="300"
                            />
                            <small>Mark device offline after no heartbeat</small>
                        </div>
                    </div>
                </div>
            </div>

            {savingSettings && (
                <div className="toast success">
                    <Save size={18} /> Saving settings...
                </div>
            )}
        </div>
    )

    // Render Dashboard (default)
    const renderDashboard = () => (
        <>
            <header className="header">
                <div>
                    <h1>Power Management Dashboard</h1>
                    <p style={{ color: 'var(--text-muted)', marginTop: 4 }}>
                        Monitor and control lab computers
                    </p>
                </div>
                <div className="action-buttons">
                    <button className="btn btn-ghost" onClick={fetchData}>
                        <RefreshCw size={18} /> Refresh
                    </button>
                    <button className="btn btn-success" onClick={() => fetch(`${API_URL}/api/devices/wake-all`, { method: 'POST' })}>
                        <Play size={18} /> Wake All
                    </button>
                    <button className="btn btn-danger" onClick={() => fetch(`${API_URL}/api/devices/shutdown-all-idle`, { method: 'POST' })}>
                        <PowerOff size={18} /> Shutdown Idle
                    </button>
                </div>
            </header>

            <div className="stats-grid">
                <div className="stat-card active">
                    <div className="stat-label"><Activity size={16} /> Active Devices</div>
                    <div className="stat-value active">{analytics?.active_devices || 0}</div>
                </div>
                <div className="stat-card idle">
                    <div className="stat-label"><AlertTriangle size={16} /> Idle Devices</div>
                    <div className="stat-value idle">{analytics?.idle_devices || 0}</div>
                </div>
                <div className="stat-card offline">
                    <div className="stat-label"><WifiOff size={16} /> Offline Devices</div>
                    <div className="stat-value offline">{analytics?.offline_devices || 0}</div>
                </div>
                <div className="stat-card savings">
                    <div className="stat-label"><Zap size={16} /> Total Savings</div>
                    <div className="stat-value savings">₹{analytics?.total_cost_saved_rupees || 0}</div>
                </div>
            </div>

            <div className="sustainability-banner glass-card" style={{ marginBottom: 24, padding: 20 }}>
                <div style={{ display: 'flex', justifyContent: 'space-around', textAlign: 'center' }}>
                    <div>
                        <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--status-active)' }}>{analytics?.total_energy_saved_kwh || 0} kWh</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Energy Saved</div>
                    </div>
                    <div>
                        <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--accent-primary)' }}>₹{analytics?.total_cost_saved_rupees || 0}</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Money Saved</div>
                    </div>
                    <div>
                        <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--status-idle)' }}>{analytics?.total_co2_reduced_kg || 0} kg</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>CO₂ Reduced</div>
                    </div>
                </div>
            </div>

            {/* All Device Categories */}
            {(() => {
                // Category definitions with icons and colors
                const categories = [
                    { type: 'admin', label: '👑 Admin Systems', color: '#7c3aed', noHibernate: true },
                    { type: 'server', label: '🌐 Server Systems', color: '#3b82f6', noHibernate: true },
                    { type: 'lab', label: '🖥️ Lab Computers', color: '#22c55e', noHibernate: false },
                    { type: 'personal', label: '💻 Personal Workstations', color: '#f97316', noHibernate: false },
                    { type: 'network', label: '🔗 Network Devices', color: '#06b6d4', noHibernate: false },
                ]

                // Sort function: active first, then idle, then offline
                const statusPriority = { active: 0, passive: 1, deep_idle: 2, offline: 3 }
                const sortByStatus = (a: any, b: any) => (statusPriority[a.status] || 3) - (statusPriority[b.status] || 3)

                // Group devices by category
                const getDevicesByType = (type: string) => {
                    return devices
                        .filter(d => (d.system_type || 'lab') === type)
                        .sort(sortByStatus)
                }

                // Render a device card
                const renderDeviceCard = (device: any, category: any) => (
                    <div
                        key={device.device_id}
                        className={`device-card ${device.status}`}
                        onClick={() => setSelectedDevice(device.device_id)}
                        style={{ borderLeft: `3px solid ${category.color}` }}
                    >
                        <div className="device-header">
                            <div className={`status-indicator ${device.status}`}></div>
                            <div>
                                <div className="device-name" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                                    {device.hostname}
                                    <span style={{ fontSize: '0.6rem', background: category.color, color: 'white', padding: '2px 5px', borderRadius: 4, textTransform: 'uppercase' }}>
                                        {device.system_type || 'lab'}
                                    </span>
                                </div>
                                <div className="device-ip">{device.ip_address}</div>
                            </div>
                        </div>
                        <div className="device-metrics">
                            <div className="metric">
                                <div className="metric-label">Status</div>
                                <div className="metric-value" style={{ color: statusColors[device.status] }}>{statusLabels[device.status]}</div>
                            </div>
                            <div className="metric">
                                <div className="metric-label">Idle Time</div>
                                <div className="metric-value">{formatIdleTime(device.idle_seconds)}</div>
                            </div>
                            <div className="metric">
                                <div className="metric-label">CPU Usage</div>
                                <div className="metric-value">{device.cpu_usage?.toFixed(1)}%</div>
                            </div>
                            <div className="metric">
                                <div className="metric-label">RAM</div>
                                <div className="metric-value">{device.ram_total_gb?.toFixed(1)} GB</div>
                            </div>
                        </div>
                    </div>
                )

                return (
                    <>
                        {loading ? (
                            <div style={{ display: 'flex', justifyContent: 'center', padding: 60 }}>
                                <div className="loading-spinner"></div>
                            </div>
                        ) : (
                            <>
                                {categories.map(category => {
                                    const categoryDevices = getDevicesByType(category.type)
                                    if (categoryDevices.length === 0) return null

                                    return (
                                        <div key={category.type} style={{ marginBottom: 32 }}>
                                            <h2 style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
                                                {category.label}
                                                <span style={{ fontSize: '0.8rem', background: 'var(--bg-card)', padding: '2px 8px', borderRadius: 12, color: 'var(--text-muted)', fontWeight: 400 }}>
                                                    {categoryDevices.length}
                                                </span>
                                                {category.noHibernate && (
                                                    <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 400, marginLeft: 4 }}>
                                                        (No auto-hibernation)
                                                    </span>
                                                )}
                                            </h2>
                                            <div className="device-grid">
                                                {categoryDevices.map(device => renderDeviceCard(device, category))}
                                            </div>
                                        </div>
                                    )
                                })}

                                {devices.length === 0 && (
                                    <div style={{ textAlign: 'center', padding: 60, color: 'var(--text-muted)' }}>
                                        <Monitor size={64} style={{ opacity: 0.3, marginBottom: 16 }} />
                                        <h3>No devices connected</h3>
                                        <p>Start the agent on computers to see them here</p>
                                    </div>
                                )}
                            </>
                        )}
                    </>
                )
            })()}
        </>
    )

    return (
        <div className="app-container">
            <aside className="sidebar">
                <div className="logo">
                    <div className="logo-icon">⚡</div>
                    <span className="logo-text">PowerSync</span>
                </div>

                <nav className="nav-menu">
                    <div className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveTab('dashboard')}>
                        <Monitor size={20} /><span>Dashboard</span>
                    </div>
                    <div className={`nav-item ${activeTab === 'analytics' ? 'active' : ''}`} onClick={() => setActiveTab('analytics')}>
                        <BarChart3 size={20} /><span>Analytics</span>
                    </div>
                    <div className={`nav-item ${activeTab === 'settings' ? 'active' : ''}`} onClick={() => setActiveTab('settings')}>
                        <Settings size={20} /><span>Settings</span>
                    </div>
                </nav>

                <div className="sidebar-stats">
                    <h4 style={{ color: 'var(--text-muted)', marginBottom: 12, fontSize: '0.75rem', textTransform: 'uppercase' }}>Quick Stats</h4>
                    {analytics && (
                        <>
                            <div className="mini-stat"><span className="mini-stat-label">Energy Saved Today</span><span className="mini-stat-value">{analytics.today_energy_saved_kwh} kWh</span></div>
                            <div className="mini-stat"><span className="mini-stat-label">Cost Saved Today</span><span className="mini-stat-value">₹{analytics.today_cost_saved_rupees}</span></div>
                        </>
                    )}
                </div>
            </aside>

            <main className="main-content">
                {activeTab === 'dashboard' && renderDashboard()}
                {activeTab === 'analytics' && renderAnalytics()}
                {activeTab === 'settings' && renderSettings()}
            </main>

            <div className={`backdrop ${selectedDevice ? 'visible' : ''}`} onClick={() => setSelectedDevice(null)} />

            <aside className={`detail-panel ${selectedDevice ? 'open' : ''}`}>
                {deviceDetail && (
                    <>
                        <div className="detail-header">
                            <div>
                                <h2>{deviceDetail.hostname}</h2>
                                <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{deviceDetail.ip_address}</div>
                            </div>
                            <button className="btn btn-ghost" onClick={() => setSelectedDevice(null)}><X size={20} /></button>
                        </div>
                        <div className="detail-content">
                            <div className="detail-section">
                                <h4>Impact This Device</h4>
                                <div className="impact-badges">
                                    <div className="impact-badge"><div className="impact-value">{deviceDetail.energy_saved_kwh}</div><div className="impact-label">kWh Saved</div></div>
                                    <div className="impact-badge"><div className="impact-value">₹{deviceDetail.cost_saved_rupees}</div><div className="impact-label">Money Saved</div></div>
                                    <div className="impact-badge"><div className="impact-value">{deviceDetail.co2_reduced_kg}</div><div className="impact-label">kg CO₂</div></div>
                                </div>
                            </div>
                            <div className="detail-section">
                                <h4>CPU Usage (Last Hour)</h4>
                                <div className="chart-container">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <AreaChart data={deviceDetail.recent_cpu_history}>
                                            <defs><linearGradient id="cpuGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} /><stop offset="95%" stopColor="#6366f1" stopOpacity={0} /></linearGradient></defs>
                                            <XAxis dataKey="timestamp" hide /><YAxis domain={[0, 100]} hide />
                                            <Tooltip contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8 }} formatter={(value) => [`${value.toFixed(1)}%`, 'CPU']} />
                                            <Area type="monotone" dataKey="value" stroke="#6366f1" fill="url(#cpuGradient)" strokeWidth={2} />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                            <div className="detail-section">
                                <h4>System Specifications</h4>
                                <div className="specs-list">
                                    <div className="spec-item"><span className="spec-label">Operating System</span><span className="spec-value">{deviceDetail.os_name} {deviceDetail.os_version}</span></div>
                                    <div className="spec-item"><span className="spec-label">Processor</span><span className="spec-value">{deviceDetail.cpu_model}</span></div>
                                    <div className="spec-item"><span className="spec-label">RAM</span><span className="spec-value">{deviceDetail.ram_total_gb} GB</span></div>
                                    <div className="spec-item"><span className="spec-label">MAC Address</span><span className="spec-value">{deviceDetail.mac_address}</span></div>
                                </div>
                            </div>
                            <div className="detail-section">
                                <h4>Quick Actions</h4>
                                <div className="action-buttons">
                                    {deviceDetail.status === 'offline' ? (
                                        <button className="btn btn-success" onClick={() => wakeDevice(deviceDetail.device_id)}><Play size={18} /> Wake Up (WOL)</button>
                                    ) : (
                                        <>
                                            <button className="btn btn-primary" onClick={() => sendCommand(deviceDetail.device_id, 'SLEEP')}><Moon size={18} /> Sleep</button>
                                            <button className="btn btn-danger" onClick={() => sendCommand(deviceDetail.device_id, 'SHUTDOWN')}><PowerOff size={18} /> Shutdown</button>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </aside>
        </div>
    )
}

export default App
