"""
Smart Power Management System - Client Agent
Monitors user activity and system metrics, sends heartbeats to central server
"""
import os
import sys
import time
import socket
import uuid
import json
import threading
import platform
import subprocess
from datetime import datetime
from typing import Optional
from pathlib import Path

import psutil
import requests
from pynput import mouse, keyboard

# ============ Configuration ============

CONFIG_FILE = Path(__file__).parent / "agent_config.json"

def load_config():
    """Load configuration from file or return defaults"""
    defaults = {
        "server_ip": "localhost",
        "server_port": 8000,
        "system_type": "lab",
        "device_name": socket.gethostname(),
        "device_id": str(uuid.getnode()),
        "grace_period": 30,
        "idle_threshold": 180,
        "heartbeat_interval": 30,
        "auto_start": False
    }
    
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                return {**defaults, **config}
        except:
            pass
    return defaults

# Load configuration
CONFIG = load_config()
SERVER_URL = f"http://{CONFIG['server_ip']}:{CONFIG['server_port']}"
HEARTBEAT_INTERVAL = CONFIG.get('heartbeat_interval', 5)  # seconds - from config (default 5s)
DEVICE_ID = CONFIG['device_id']
DEVICE_NAME = CONFIG['device_name']
SYSTEM_TYPE = CONFIG['system_type']
GRACE_PERIOD = CONFIG['grace_period']
IDLE_THRESHOLD = min(CONFIG['idle_threshold'], 180)  # Max 3 mins



# ============ Activity Tracker ============

class ActivityTracker:
    """Tracks mouse and keyboard activity to detect idle state"""
    
    def __init__(self):
        self.last_activity_time = time.time()
        self.running = False
        self._mouse_listener = None
        self._keyboard_listener = None
        self._lock = threading.Lock()
    
    def _on_activity(self, *args):
        """Called on any mouse or keyboard event"""
        with self._lock:
            self.last_activity_time = time.time()
    
    def start(self):
        """Start listening for input events"""
        self.running = True
        
        # Mouse listener
        self._mouse_listener = mouse.Listener(
            on_move=self._on_activity,
            on_click=self._on_activity,
            on_scroll=self._on_activity
        )
        self._mouse_listener.start()
        
        # Keyboard listener
        self._keyboard_listener = keyboard.Listener(
            on_press=self._on_activity,
            on_release=self._on_activity
        )
        self._keyboard_listener.start()
        
        print("✅ Activity tracking started")
    
    def stop(self):
        """Stop listening"""
        self.running = False
        if self._mouse_listener:
            self._mouse_listener.stop()
        if self._keyboard_listener:
            self._keyboard_listener.stop()
        print("⏹️ Activity tracking stopped")
    
    @property
    def idle_seconds(self) -> int:
        """Get current idle time in seconds"""
        with self._lock:
            return int(time.time() - self.last_activity_time)


# ============ System Info Collector ============

class SystemInfo:
    """Collects system information and metrics"""
    
    @staticmethod
    def get_hostname() -> str:
        return socket.gethostname()
    
    @staticmethod
    def get_ip_address() -> str:
        """Get the primary IP address"""
        try:
            # Connect to a remote address to find the outgoing interface
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    @staticmethod
    def get_mac_address() -> str:
        """Get MAC address of primary network interface"""
        mac = ':'.join(['{:02x}'.format((uuid.getnode() >> i) & 0xff) for i in range(0, 48, 8)][::-1])
        return mac.upper()
    
    @staticmethod
    def get_cpu_usage() -> float:
        """Get current CPU usage percentage"""
        return psutil.cpu_percent(interval=1)
    
    @staticmethod
    def get_ram_usage() -> float:
        """Get current RAM usage percentage"""
        return psutil.virtual_memory().percent
    
    @staticmethod
    def get_os_info() -> tuple:
        """Get OS name and version - friendly names using PowerShell"""
        os_name = platform.system()
        os_version = platform.version()
        
        if os_name == "Windows":
            try:
                # Use PowerShell Get-CimInstance for accurate OS name
                import subprocess
                result = subprocess.run(
                    ['powershell', '-Command', 
                     '(Get-CimInstance Win32_OperatingSystem).Caption'],
                    capture_output=True, text=True, timeout=10,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                if result.returncode == 0 and result.stdout.strip():
                    os_name = result.stdout.strip()
                    # Get build number
                    os_version = platform.version().split('.')[-1]
            except:
                pass
        
        return os_name, os_version
    
    @staticmethod
    def get_cpu_model() -> str:
        """Get CPU model name - accurate detection using PowerShell"""
        if platform.system() == "Windows":
            try:
                # Use PowerShell Get-CimInstance for accurate CPU name
                import subprocess
                result = subprocess.run(
                    ['powershell', '-Command',
                     '(Get-CimInstance Win32_Processor).Name'],
                    capture_output=True, text=True, timeout=10,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                if result.returncode == 0 and result.stdout.strip():
                    return result.stdout.strip()
            except:
                pass
            # Fallback to platform.processor()
            return platform.processor()
        elif platform.system() == "Linux":
            try:
                with open("/proc/cpuinfo") as f:
                    for line in f:
                        if "model name" in line:
                            return line.split(":")[1].strip()
            except:
                pass
        return "Unknown"
    
    @staticmethod
    def get_total_ram_gb() -> float:
        """Get total RAM in GB"""
        return round(psutil.virtual_memory().total / (1024**3), 2)


# ============ Command Executor ============

class CommandExecutor:
    """Executes power commands received from server"""
    
    @staticmethod
    def shutdown(grace_seconds: int = 60, message: str = ""):
        """Initiate system shutdown"""
        print(f"⚠️ Shutdown scheduled in {grace_seconds} seconds")
        
        if platform.system() == "Windows":
            # Windows shutdown command
            subprocess.run([
                "shutdown", "/s", "/t", str(grace_seconds),
                "/c", message or "Power Management: System shutting down due to inactivity"
            ])
        else:
            # Linux/Mac shutdown
            subprocess.run(["shutdown", "-h", f"+{grace_seconds // 60}", message])
    
    @staticmethod
    def cancel_shutdown():
        """Cancel a pending shutdown"""
        if platform.system() == "Windows":
            subprocess.run(["shutdown", "/a"])
        else:
            subprocess.run(["shutdown", "-c"])
        print("✅ Shutdown cancelled")
    
    @staticmethod
    def sleep():
        """Put system to sleep"""
        print("💤 Entering sleep mode")
        
        if platform.system() == "Windows":
            subprocess.run(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
        else:
            subprocess.run(["systemctl", "suspend"])
    
    @staticmethod
    def restart(grace_seconds: int = 60):
        """Restart system"""
        print(f"🔄 Restart scheduled in {grace_seconds} seconds")
        
        if platform.system() == "Windows":
            subprocess.run(["shutdown", "/r", "/t", str(grace_seconds)])
        else:
            subprocess.run(["shutdown", "-r", f"+{grace_seconds // 60}"])


# ============ Grace Period Warning ============

class GracePeriodWarning:
    """Shows a warning popup before executing power commands"""
    
    def __init__(self, message: str, countdown_seconds: int, on_cancel: callable):
        self.message = message
        self.countdown = countdown_seconds
        self.on_cancel = on_cancel
        self.cancelled = False
        self._activity_tracker = None
        self._initial_idle = 0
    
    def show(self, activity_tracker: 'ActivityTracker'):
        """Show warning and start countdown"""
        self._activity_tracker = activity_tracker
        self._initial_idle = activity_tracker.idle_seconds
        
        try:
            # Try to show GUI warning
            self._show_tkinter_warning()
        except:
            # Fallback to console warning
            self._show_console_warning()
    
    def _show_console_warning(self):
        """Console-based warning"""
        print(f"\n{'='*50}")
        print(f"⚠️  WARNING: {self.message}")
        print(f"⚠️  Action will execute in {self.countdown} seconds")
        print(f"⚠️  Move mouse or press any key to cancel")
        print(f"{'='*50}\n")
        
        for remaining in range(self.countdown, 0, -1):
            if self._check_activity():
                print("✅ Activity detected - Action cancelled!")
                self.cancelled = True
                self.on_cancel()
                return
            print(f"⏱️  {remaining} seconds remaining...", end='\r')
            time.sleep(1)
        
        if not self.cancelled:
            print("\n⚡ Executing action...")
    
    def _show_tkinter_warning(self):
        """GUI warning using Tkinter - Improved Hibernation Warning"""
        import tkinter as tk
        from tkinter import ttk
        
        root = tk.Tk()
        root.title("⚠️ PowerSync - Hibernation Warning")
        root.attributes('-topmost', True)
        root.overrideredirect(False)  # Keep window decorations
        root.geometry("500x320")
        root.configure(bg='#1a1a2e')
        root.resizable(False, False)
        
        # Center the window
        root.update_idletasks()
        x = (root.winfo_screenwidth() - 500) // 2
        y = (root.winfo_screenheight() - 320) // 2
        root.geometry(f"+{x}+{y}")
        
        # Make window stay on top and grab focus
        root.lift()
        root.focus_force()
        
        # Header
        header_frame = tk.Frame(root, bg='#7c3aed', height=60)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        header_label = tk.Label(
            header_frame,
            text="⚡ PowerSync - System Idle Detected",
            font=("Segoe UI", 14, "bold"),
            fg='white',
            bg='#7c3aed'
        )
        header_label.pack(expand=True)
        
        # Warning icon and message
        content_frame = tk.Frame(root, bg='#1a1a2e')
        content_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        warning_icon = tk.Label(
            content_frame,
            text="💤",
            font=("Segoe UI", 48),
            bg='#1a1a2e'
        )
        warning_icon.pack(pady=(0, 10))
        
        message_label = tk.Label(
            content_frame,
            text=f"{self.message}",
            font=("Segoe UI", 11),
            fg='#fbbf24',
            bg='#1a1a2e',
            wraplength=420
        )
        message_label.pack()
        
        # Countdown display
        countdown_frame = tk.Frame(content_frame, bg='#1a1a2e')
        countdown_frame.pack(pady=15)
        
        countdown_text = tk.Label(
            countdown_frame,
            text="Hibernating in:",
            font=("Segoe UI", 10),
            fg='#94a3b8',
            bg='#1a1a2e'
        )
        countdown_text.pack()
        
        self.countdown_var = tk.StringVar(value=f"{self.countdown}")
        countdown_number = tk.Label(
            countdown_frame,
            textvariable=self.countdown_var,
            font=("Segoe UI", 36, "bold"),
            fg='#ef4444',
            bg='#1a1a2e'
        )
        countdown_number.pack()
        
        seconds_label = tk.Label(
            countdown_frame,
            text="seconds",
            font=("Segoe UI", 10),
            fg='#94a3b8',
            bg='#1a1a2e'
        )
        seconds_label.pack()
        
        # Cancel button
        def cancel():
            self.cancelled = True
            self.on_cancel()
            root.destroy()
        
        cancel_btn = tk.Button(
            content_frame,
            text="🖱️  Move Mouse or Press Any Key to Cancel",
            command=cancel,
            font=("Segoe UI", 11, "bold"),
            bg='#22c55e',
            fg='white',
            padx=25,
            pady=12,
            relief=tk.FLAT,
            cursor='hand2',
            activebackground='#16a34a',
            activeforeground='white'
        )
        cancel_btn.pack(pady=(10, 0))
        
        # Countdown logic
        remaining = [self.countdown]
        
        def update_countdown():
            if self.cancelled:
                return
            
            # Check for activity
            if self._check_activity():
                self.cancelled = True
                self.on_cancel()
                try:
                    root.destroy()
                except:
                    pass
                return
            
            remaining[0] -= 1
            self.countdown_var.set(f"{remaining[0]}")
            
            # Change color as time runs out
            if remaining[0] <= 10:
                countdown_number.config(fg='#dc2626')  # Darker red
            elif remaining[0] <= 20:
                countdown_number.config(fg='#ef4444')  # Red
            
            if remaining[0] <= 0:
                try:
                    root.destroy()
                except:
                    pass
            else:
                root.after(1000, update_countdown)
        
        root.after(1000, update_countdown)
        
        # Handle window close
        def on_close():
            cancel()
        
        root.protocol("WM_DELETE_WINDOW", on_close)
        root.mainloop()
    
    def _check_activity(self) -> bool:
        """Check if user has been active since warning started"""
        if self._activity_tracker:
            # If idle time has decreased, user is active
            return self._activity_tracker.idle_seconds < self._initial_idle - 2
        return False


# ============ Main Agent ============

class PowerManagementAgent:
    """Main agent that coordinates all components"""
    
    def __init__(self, server_url: str, device_id: str):
        self.server_url = server_url.rstrip('/')
        self.device_id = device_id
        self.activity_tracker = ActivityTracker()
        self.system_info = SystemInfo()
        self.command_executor = CommandExecutor()
        self.running = False
        self._pending_command = None
        self._specs_sent = False
    
    def wait_for_server(self):
        """Wait indefinitely for server to become available"""
        retry_delay = 10  # Fixed 10 seconds between retries
        
        print(f"🔄 Waiting for server at {self.server_url}...")
        
        while self.running:
            try:
                response = requests.get(
                    f"{self.server_url}/health",
                    timeout=5
                )
                if response.status_code == 200:
                    print(f"✅ Server is online! Starting agent...")
                    return True
            except requests.exceptions.ConnectionError:
                print(f"⏳ Server not available. Retrying in {retry_delay}s...")
            except Exception as e:
                print(f"⚠️ Connection error: {e}. Retrying in {retry_delay}s...")
            
            time.sleep(retry_delay)
            # Fixed interval - no exponential backoff
        
        return False
    
    def start(self):
        """Start the agent"""
        print(f"""
╔══════════════════════════════════════════════════════╗
║   Smart Power Management System - Client Agent       ║
╠══════════════════════════════════════════════════════╣
║   Device ID: {self.device_id[:20]:^20}...      ║
║   Server:    {self.server_url[:30]:^30}       ║
╚══════════════════════════════════════════════════════╝
        """)
        
        self.running = True
        
        # Wait for server to be available before starting
        if not self.wait_for_server():
            print("❌ Could not connect to server. Exiting.")
            return
        
        self.activity_tracker.start()
        
        # Start heartbeat loop
        self._heartbeat_loop()
    
    def stop(self):
        """Stop the agent"""
        self.running = False
        self.activity_tracker.stop()
        print("👋 Agent stopped")
    
    def _build_heartbeat_payload(self) -> dict:
        """Build the heartbeat payload"""
        payload = {
            "device_id": self.device_id,
            "hostname": self.system_info.get_hostname(),
            "ip_address": self.system_info.get_ip_address(),
            "mac_address": self.system_info.get_mac_address(),
            "idle_seconds": self.activity_tracker.idle_seconds,
            "cpu_usage": self.system_info.get_cpu_usage(),
            "ram_usage": self.system_info.get_ram_usage(),
            "system_type": SYSTEM_TYPE  # Include system type in every heartbeat
        }
        
        # Include system specs on first heartbeat
        if not self._specs_sent:
            os_name, os_version = self.system_info.get_os_info()
            payload.update({
                "os_name": os_name,
                "os_version": os_version,
                "cpu_model": self.system_info.get_cpu_model(),
                "ram_total_gb": self.system_info.get_total_ram_gb()
            })
            self._specs_sent = True
        
        return payload
    
    def _send_heartbeat(self) -> Optional[dict]:
        """Send heartbeat to server and get response"""
        try:
            payload = self._build_heartbeat_payload()
            
            response = requests.post(
                f"{self.server_url}/api/heartbeat",
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"⚠️ Server returned status {response.status_code}")
                return None
                
        except requests.exceptions.ConnectionError:
            print(f"❌ Cannot connect to server at {self.server_url}")
            return None
        except Exception as e:
            print(f"❌ Heartbeat error: {e}")
            return None
    
    def _handle_command(self, response: dict):
        """Handle command from server"""
        command = response.get("command", "STAY_AWAKE")
        message = response.get("message", "")
        grace_period = response.get("grace_period_seconds", 60)
        
        # Skip hibernation/shutdown/sleep for admin/server systems
        if SYSTEM_TYPE in ["admin", "server"]:
            if command in ["SHUTDOWN", "SLEEP", "RESTART"]:
                print(f"ℹ️ Admin/Server system - ignoring {command} command")
                return
        
        if command == "STAY_AWAKE":
            return  # Nothing to do
        
        if command == "MESSAGE":
            print(f"📨 Message from server: {message}")
            return
        
        # For SHUTDOWN, SLEEP, RESTART - show warning first
        if command in ["SHUTDOWN", "SLEEP", "RESTART"]:
            if self._pending_command == command:
                return  # Already pending
            
            self._pending_command = command
            
            def on_cancel():
                print(f"✅ {command} cancelled by user activity")
                self._pending_command = None
                if command == "SHUTDOWN":
                    self.command_executor.cancel_shutdown()
            
            warning = GracePeriodWarning(
                message or f"System will {command.lower()} due to inactivity",
                grace_period,
                on_cancel
            )
            
            # Run warning in separate thread
            warning_thread = threading.Thread(
                target=warning.show,
                args=(self.activity_tracker,)
            )
            warning_thread.start()
            warning_thread.join()
            
            # Execute if not cancelled
            if not warning.cancelled:
                self._execute_command(command, grace_period)
                self._pending_command = None
    
    def _execute_command(self, command: str, grace_period: int = 0):
        """Execute a power command"""
        if command == "SHUTDOWN":
            self.command_executor.shutdown(grace_seconds=0)
        elif command == "SLEEP":
            self.command_executor.sleep()
        elif command == "RESTART":
            self.command_executor.restart(grace_seconds=0)
    
    def _heartbeat_loop(self):
        """Main heartbeat loop"""
        while self.running:
            try:
                idle = self.activity_tracker.idle_seconds
                status = "active" if idle < 60 else ("idle" if idle < 300 else "deep_idle")
                
                print(f"💓 Heartbeat | Idle: {idle}s | Status: {status} | CPU: {psutil.cpu_percent()}%")
                
                response = self._send_heartbeat()
                
                if response:
                    self._handle_command(response)
                
                # Wait for next interval
                time.sleep(HEARTBEAT_INTERVAL)
                
            except KeyboardInterrupt:
                print("\n⏹️ Received interrupt signal")
                self.stop()
                break
            except Exception as e:
                print(f"❌ Error in heartbeat loop: {e}")
                time.sleep(5)  # Wait before retry


# ============ Entry Point ============

def main():
    """Main entry point"""
    agent = PowerManagementAgent(SERVER_URL, DEVICE_ID)
    
    try:
        agent.start()
    except KeyboardInterrupt:
        agent.stop()
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        agent.stop()
        sys.exit(1)


if __name__ == "__main__":
    main()
