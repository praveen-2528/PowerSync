"""
Analytics service for calculating energy savings
"""
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import func
from models import Device, PowerEvent, Settings


def get_setting(db: Session, key: str, default: str = "0") -> str:
    """Get a setting value by key"""
    from models import Settings
    setting = db.query(Settings).filter(Settings.key == key).first()
    return setting.value if setting else default


def calculate_device_energy_savings(db: Session, device: Device) -> dict:
    """
    Calculate energy savings for a specific device
    
    Formula:
    - Energy_Saved (kWh) = (Total_Off_Hours * Avg_PC_Wattage) / 1000
    - Cost_Saved = Energy_Saved * Cost_Per_Unit
    - CO2_Reduction = Energy_Saved * Carbon_Intensity_Factor
    """
    avg_wattage = float(get_setting(db, "avg_pc_wattage", "200"))
    cost_per_kwh = float(get_setting(db, "cost_per_kwh", "8.0"))
    carbon_intensity = float(get_setting(db, "carbon_intensity", "0.82"))
    
    # Calculate hours powered off (saved)
    total_off_hours = device.total_powered_off_minutes / 60.0
    
    # Energy saved calculation
    energy_saved_kwh = (total_off_hours * avg_wattage) / 1000.0
    cost_saved = energy_saved_kwh * cost_per_kwh
    co2_reduced = energy_saved_kwh * carbon_intensity
    
    return {
        "energy_saved_kwh": round(energy_saved_kwh, 2),
        "cost_saved_rupees": round(cost_saved, 2),
        "co2_reduced_kg": round(co2_reduced, 3)
    }


def calculate_system_analytics(db: Session) -> dict:
    """Calculate system-wide analytics"""
    avg_wattage = float(get_setting(db, "avg_pc_wattage", "200"))
    cost_per_kwh = float(get_setting(db, "cost_per_kwh", "8.0"))
    carbon_intensity = float(get_setting(db, "carbon_intensity", "0.82"))
    
    # Device counts
    devices = db.query(Device).all()
    total_devices = len(devices)
    active_count = sum(1 for d in devices if d.status == "active")
    idle_count = sum(1 for d in devices if d.status in ["passive", "deep_idle"])
    offline_count = sum(1 for d in devices if d.status == "offline")
    
    # Total savings
    total_off_minutes = sum(d.total_powered_off_minutes for d in devices)
    total_off_hours = total_off_minutes / 60.0
    
    total_energy_kwh = (total_off_hours * avg_wattage) / 1000.0
    total_cost = total_energy_kwh * cost_per_kwh
    total_co2 = total_energy_kwh * carbon_intensity
    
    # Today's savings (from power events)
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    today_events = db.query(PowerEvent).filter(
        PowerEvent.timestamp >= today_start,
        PowerEvent.event_type == "SHUTDOWN"
    ).count()
    
    # Estimate today's savings (rough: each shutdown saves ~30 mins average)
    today_saved_hours = (today_events * 30) / 60.0
    today_energy = (today_saved_hours * avg_wattage) / 1000.0
    today_cost = today_energy * cost_per_kwh
    
    # This month's savings
    month_start = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    month_events = db.query(PowerEvent).filter(
        PowerEvent.timestamp >= month_start,
        PowerEvent.event_type == "SHUTDOWN"
    ).count()
    
    month_saved_hours = (month_events * 30) / 60.0
    month_energy = (month_saved_hours * avg_wattage) / 1000.0
    month_cost = month_energy * cost_per_kwh
    
    return {
        "total_devices": total_devices,
        "active_devices": active_count,
        "idle_devices": idle_count,
        "offline_devices": offline_count,
        "total_energy_saved_kwh": round(total_energy_kwh, 2),
        "total_cost_saved_rupees": round(total_cost, 2),
        "total_co2_reduced_kg": round(total_co2, 3),
        "today_energy_saved_kwh": round(today_energy, 2),
        "today_cost_saved_rupees": round(today_cost, 2),
        "this_month_energy_saved_kwh": round(month_energy, 2),
        "this_month_cost_saved_rupees": round(month_cost, 2)
    }
