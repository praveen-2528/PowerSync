"""
Smart Power Management System - Client Agent Setup GUI
PyQt6-based configuration wizard for client setup
"""
import os
import sys
import json
import socket
import uuid
import platform
import subprocess
from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QComboBox, QSlider, QPushButton, QGroupBox,
    QFormLayout, QMessageBox, QFrame, QSpacerItem, QSizePolicy,
    QScrollArea
)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QFont, QIcon, QPalette, QColor

# Config file path
CONFIG_FILE = Path(__file__).parent / "agent_config.json"

# Default configuration
DEFAULT_CONFIG = {
    "server_ip": "localhost",
    "server_port": 8000,
    "system_type": "lab",
    "device_name": "",
    "device_id": "",
    "grace_period": 30,
    "idle_threshold": 180,
    "heartbeat_interval": 5,
    "auto_start": False
}


def get_system_info():
    """Get system information for auto-fill"""
    hostname = socket.gethostname()
    device_id = str(uuid.getnode())
    
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip_address = s.getsockname()[0]
        s.close()
    except:
        ip_address = "127.0.0.1"
    
    return {
        "hostname": hostname,
        "device_id": device_id,
        "ip_address": ip_address,
        "os": platform.system(),
        "os_version": platform.version()
    }


def load_config():
    """Load configuration from file"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                return {**DEFAULT_CONFIG, **config}
        except:
            pass
    return DEFAULT_CONFIG.copy()


def save_config(config):
    """Save configuration to file"""
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)


class SetupWindow(QMainWindow):
    """Main Setup Window"""
    
    def __init__(self):
        super().__init__()
        self.config = load_config()
        self.system_info = get_system_info()
        
        # Auto-fill device info if empty
        if not self.config["device_name"]:
            self.config["device_name"] = self.system_info["hostname"]
        if not self.config["device_id"]:
            self.config["device_id"] = self.system_info["device_id"]
        
        self.init_ui()
    
    def init_ui(self):
        """Initialize the UI"""
        self.setWindowTitle("⚡ PowerSync - Agent Setup")
        self.setMinimumSize(600, 700)
        self.resize(620, 800)
        self.setStyleSheet(self.get_stylesheet())
        
        # Central widget with scroll area
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Scroll Area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { border: none; background-color: #1a1a2e; }")
        
        # Scroll content widget
        scroll_content = QWidget()
        scroll_content.setStyleSheet("background-color: #1a1a2e;")
        layout = QVBoxLayout(scroll_content)
        layout.setSpacing(20)
        layout.setContentsMargins(30, 30, 30, 20)
        
        # Header
        header = QLabel("⚡ PowerSync Agent Setup")
        header.setObjectName("header")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(header)
        
        # Subtitle
        subtitle = QLabel("Configure your power management agent")
        subtitle.setObjectName("subtitle")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)
        
        layout.addSpacing(15)
        
        # =============== Server Connection ===============
        server_group = QGroupBox("🖥️  Server Connection")
        server_layout = QFormLayout(server_group)
        server_layout.setSpacing(15)
        server_layout.setContentsMargins(20, 25, 20, 20)
        
        self.ip_input = QLineEdit(self.config["server_ip"])
        self.ip_input.setPlaceholderText("e.g., 192.168.1.100")
        self.ip_input.setMinimumHeight(40)
        server_layout.addRow("Admin Server IP:", self.ip_input)
        
        self.port_input = QLineEdit(str(self.config["server_port"]))
        self.port_input.setPlaceholderText("e.g., 8000")
        self.port_input.setMaximumWidth(120)
        self.port_input.setMinimumHeight(40)
        server_layout.addRow("Port:", self.port_input)
        
        layout.addWidget(server_group)
        
        # =============== System Classification ===============
        type_group = QGroupBox("📋  System Classification")
        type_layout = QFormLayout(type_group)
        type_layout.setSpacing(15)
        type_layout.setContentsMargins(20, 25, 20, 20)
        
        self.type_combo = QComboBox()
        self.type_combo.setMinimumHeight(40)
        self.type_combo.addItems([
            "🖥️  Lab Computer",
            "💻  Personal Workstation", 
            "🌐  Network Device",
            "👤  Admin System",
            "📊  Server"
        ])
        type_values = ["lab", "personal", "network", "admin", "server"]
        current_idx = type_values.index(self.config["system_type"]) if self.config["system_type"] in type_values else 0
        self.type_combo.setCurrentIndex(current_idx)
        type_layout.addRow("System Type:", self.type_combo)
        
        layout.addWidget(type_group)
        
        # =============== Device Information ===============
        device_group = QGroupBox("🔧  Device Information")
        device_layout = QFormLayout(device_group)
        device_layout.setSpacing(15)
        device_layout.setContentsMargins(20, 25, 20, 20)
        
        self.name_input = QLineEdit(self.config["device_name"])
        self.name_input.setPlaceholderText("Enter device name")
        self.name_input.setMinimumHeight(40)
        device_layout.addRow("Device Name:", self.name_input)
        
        self.id_input = QLineEdit(self.config["device_id"])
        self.id_input.setPlaceholderText("Auto-generated device ID")
        self.id_input.setMinimumHeight(40)
        device_layout.addRow("Device ID:", self.id_input)
        
        # System info label
        info_text = f"Detected: {self.system_info['os']} | IP: {self.system_info['ip_address']}"
        info_label = QLabel(info_text)
        info_label.setObjectName("info")
        device_layout.addRow("", info_label)
        
        layout.addWidget(device_group)
        
        # =============== Power Settings ===============
        power_group = QGroupBox("⏱️  Power Management Settings")
        power_layout = QVBoxLayout(power_group)
        power_layout.setSpacing(20)
        power_layout.setContentsMargins(20, 25, 20, 20)
        
        # Idle Threshold
        idle_container = QWidget()
        idle_layout = QVBoxLayout(idle_container)
        idle_layout.setContentsMargins(0, 0, 0, 0)
        idle_layout.setSpacing(10)
        
        idle_label = QLabel("Idle Threshold (seconds before hibernation):")
        idle_label.setStyleSheet("font-weight: bold;")
        idle_layout.addWidget(idle_label)
        
        idle_slider_layout = QHBoxLayout()
        idle_slider_layout.setSpacing(15)
        
        self.idle_slider = QSlider(Qt.Orientation.Horizontal)
        self.idle_slider.setMinimum(60)
        self.idle_slider.setMaximum(180)
        self.idle_slider.setValue(self.config["idle_threshold"])
        self.idle_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.idle_slider.setTickInterval(30)
        self.idle_slider.setMinimumHeight(30)
        self.idle_slider.valueChanged.connect(self.update_idle_label)
        idle_slider_layout.addWidget(self.idle_slider)
        
        self.idle_value_label = QLabel(f"{self.config['idle_threshold']}s (3 min max)")
        self.idle_value_label.setObjectName("slider_value")
        self.idle_value_label.setMinimumWidth(120)
        idle_slider_layout.addWidget(self.idle_value_label)
        idle_layout.addLayout(idle_slider_layout)
        power_layout.addWidget(idle_container)
        
        # Grace Period
        grace_container = QWidget()
        grace_layout = QVBoxLayout(grace_container)
        grace_layout.setContentsMargins(0, 0, 0, 0)
        grace_layout.setSpacing(10)
        
        grace_label = QLabel("Grace Period (warning popup duration):")
        grace_label.setStyleSheet("font-weight: bold;")
        grace_layout.addWidget(grace_label)
        
        grace_slider_layout = QHBoxLayout()
        grace_slider_layout.setSpacing(15)
        
        self.grace_slider = QSlider(Qt.Orientation.Horizontal)
        self.grace_slider.setMinimum(10)
        self.grace_slider.setMaximum(60)
        self.grace_slider.setValue(self.config["grace_period"])
        self.grace_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.grace_slider.setTickInterval(10)
        self.grace_slider.setMinimumHeight(30)
        self.grace_slider.valueChanged.connect(self.update_grace_label)
        grace_slider_layout.addWidget(self.grace_slider)
        
        self.grace_value_label = QLabel(f"{self.config['grace_period']} seconds")
        self.grace_value_label.setObjectName("slider_value")
        self.grace_value_label.setMinimumWidth(120)
        grace_slider_layout.addWidget(self.grace_value_label)
        grace_layout.addLayout(grace_slider_layout)
        power_layout.addWidget(grace_container)
        
        # Heartbeat Interval
        heartbeat_container = QWidget()
        heartbeat_layout = QVBoxLayout(heartbeat_container)
        heartbeat_layout.setContentsMargins(0, 0, 0, 0)
        heartbeat_layout.setSpacing(10)
        
        heartbeat_label = QLabel("Heartbeat Interval (seconds between server updates):")
        heartbeat_label.setStyleSheet("font-weight: bold;")
        heartbeat_layout.addWidget(heartbeat_label)
        
        heartbeat_slider_layout = QHBoxLayout()
        heartbeat_slider_layout.setSpacing(15)
        
        self.heartbeat_slider = QSlider(Qt.Orientation.Horizontal)
        self.heartbeat_slider.setMinimum(1)
        self.heartbeat_slider.setMaximum(120)
        self.heartbeat_slider.setValue(self.config.get("heartbeat_interval", 30))
        self.heartbeat_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.heartbeat_slider.setTickInterval(10)
        self.heartbeat_slider.setMinimumHeight(30)
        self.heartbeat_slider.valueChanged.connect(self.update_heartbeat_label)
        heartbeat_slider_layout.addWidget(self.heartbeat_slider)
        
        self.heartbeat_value_label = QLabel(f"{self.config.get('heartbeat_interval', 30)} seconds")
        self.heartbeat_value_label.setObjectName("slider_value")
        self.heartbeat_value_label.setMinimumWidth(120)
        heartbeat_slider_layout.addWidget(self.heartbeat_value_label)
        heartbeat_layout.addLayout(heartbeat_slider_layout)
        power_layout.addWidget(heartbeat_container)
        
        # Warning info
        warning_label = QLabel("⚠️ When idle reaches threshold, a popup will warn before hibernation.\n    Move mouse or press any key to cancel.")
        warning_label.setObjectName("warning")
        warning_label.setWordWrap(True)
        power_layout.addWidget(warning_label)
        
        layout.addWidget(power_group)
        
        # Spacer
        layout.addSpacerItem(QSpacerItem(20, 30, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding))
        
        scroll.setWidget(scroll_content)
        main_layout.addWidget(scroll)
        
        # =============== Buttons (Outside scroll area) ===============
        btn_container = QWidget()
        btn_container.setStyleSheet("background-color: #12121a; border-top: 1px solid #3d3d5c;")
        btn_layout = QHBoxLayout(btn_container)
        btn_layout.setSpacing(15)
        btn_layout.setContentsMargins(30, 20, 30, 20)
        
        # Cancel button
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("cancel_btn")
        cancel_btn.setMinimumHeight(45)
        cancel_btn.clicked.connect(self.close)
        btn_layout.addWidget(cancel_btn)
        
        btn_layout.addStretch()
        
        # Save button
        save_btn = QPushButton("💾  Save Settings")
        save_btn.setObjectName("save_btn")
        save_btn.setMinimumHeight(45)
        save_btn.clicked.connect(self.save_only)
        btn_layout.addWidget(save_btn)
        
        # Start button
        start_btn = QPushButton("▶️  Save && Start Agent")
        start_btn.setObjectName("start_btn")
        start_btn.setMinimumHeight(45)
        start_btn.setMinimumWidth(180)
        start_btn.clicked.connect(self.save_and_start)
        btn_layout.addWidget(start_btn)
        
        main_layout.addWidget(btn_container)
    
    def get_stylesheet(self):
        """Return the stylesheet"""
        return """
            QMainWindow {
                background-color: #1a1a2e;
            }
            QWidget {
                color: #e0e0e0;
                font-family: 'Segoe UI', Arial, sans-serif;
                font-size: 10pt;
            }
            QLabel#header {
                font-size: 22pt;
                font-weight: bold;
                color: #a78bfa;
                padding: 15px;
            }
            QLabel#subtitle {
                font-size: 11pt;
                color: #6b7280;
                margin-bottom: 15px;
            }
            QLabel#info {
                color: #6b7280;
                font-size: 9pt;
                padding: 5px 0;
            }
            QLabel#warning {
                color: #fbbf24;
                font-size: 9pt;
                padding: 15px;
                background-color: rgba(251, 191, 36, 0.1);
                border-radius: 8px;
                margin-top: 10px;
            }
            QLabel#slider_value {
                color: #a78bfa;
                font-weight: bold;
                font-size: 11pt;
            }
            QGroupBox {
                font-weight: bold;
                font-size: 11pt;
                color: #a78bfa;
                border: 1px solid #3d3d5c;
                border-radius: 10px;
                margin-top: 15px;
                padding: 20px;
                padding-top: 30px;
                background-color: rgba(45, 45, 68, 0.3);
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 20px;
                padding: 0 10px;
            }
            QLineEdit {
                background-color: #2d2d44;
                border: 1px solid #3d3d5c;
                border-radius: 6px;
                padding: 10px 15px;
                color: #ffffff;
                font-size: 10pt;
            }
            QLineEdit:focus {
                border: 2px solid #7c3aed;
            }
            QComboBox {
                background-color: #2d2d44;
                border: 1px solid #3d3d5c;
                border-radius: 6px;
                padding: 10px 15px;
                color: #ffffff;
                min-width: 220px;
            }
            QComboBox:focus {
                border: 2px solid #7c3aed;
            }
            QComboBox::drop-down {
                border: none;
                width: 35px;
            }
            QComboBox QAbstractItemView {
                background-color: #2d2d44;
                color: #ffffff;
                selection-background-color: #7c3aed;
                padding: 5px;
            }
            QSlider::groove:horizontal {
                height: 10px;
                background: #3d3d5c;
                border-radius: 5px;
            }
            QSlider::handle:horizontal {
                background: #7c3aed;
                width: 22px;
                margin: -6px 0;
                border-radius: 11px;
            }
            QSlider::handle:horizontal:hover {
                background: #8b5cf6;
            }
            QSlider::sub-page:horizontal {
                background: #7c3aed;
                border-radius: 5px;
            }
            QPushButton {
                padding: 12px 28px;
                border-radius: 8px;
                font-weight: bold;
                font-size: 10pt;
            }
            QPushButton#cancel_btn {
                background-color: #4b5563;
                color: white;
                border: none;
                min-width: 100px;
            }
            QPushButton#cancel_btn:hover {
                background-color: #6b7280;
            }
            QPushButton#save_btn {
                background-color: #374151;
                color: white;
                border: 1px solid #4b5563;
                min-width: 140px;
            }
            QPushButton#save_btn:hover {
                background-color: #4b5563;
            }
            QPushButton#start_btn {
                background-color: #7c3aed;
                color: white;
                border: none;
            }
            QPushButton#start_btn:hover {
                background-color: #6d28d9;
            }
            QScrollBar:vertical {
                background: #1a1a2e;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background: #4b5563;
                border-radius: 6px;
                min-height: 30px;
            }
            QScrollBar::handle:vertical:hover {
                background: #6b7280;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0;
            }
        """
    
    def update_idle_label(self, value):
        """Update idle threshold label"""
        mins = value // 60
        secs = value % 60
        self.idle_value_label.setText(f"{value}s ({mins}m {secs}s)")
    
    def update_grace_label(self, value):
        """Update grace period label"""
        self.grace_value_label.setText(f"{value} seconds")
    
    def update_heartbeat_label(self, value):
        """Update heartbeat interval label"""
        self.heartbeat_value_label.setText(f"{value} seconds")
    
    def validate_inputs(self):
        """Validate all inputs"""
        if not self.ip_input.text().strip():
            QMessageBox.critical(self, "Error", "Server IP is required")
            return False
        
        try:
            port = int(self.port_input.text())
            if port < 1 or port > 65535:
                raise ValueError()
        except:
            QMessageBox.critical(self, "Error", "Port must be a number between 1-65535")
            return False
        
        if not self.name_input.text().strip():
            QMessageBox.critical(self, "Error", "Device name is required")
            return False
        
        return True
    
    def get_config(self):
        """Get current configuration from form"""
        type_values = ["lab", "personal", "network", "admin", "server"]
        return {
            "server_ip": self.ip_input.text().strip(),
            "server_port": int(self.port_input.text()),
            "system_type": type_values[self.type_combo.currentIndex()],
            "device_name": self.name_input.text().strip(),
            "device_id": self.id_input.text().strip(),
            "grace_period": self.grace_slider.value(),
            "idle_threshold": min(self.idle_slider.value(), 180),
            "heartbeat_interval": self.heartbeat_slider.value(),
            "auto_start": True
        }
    
    def save_only(self):
        """Save settings without starting agent"""
        if self.validate_inputs():
            config = self.get_config()
            save_config(config)
            QMessageBox.information(self, "Success", "✅ Settings saved successfully!")
    
    def save_and_start(self):
        """Save settings and start the agent"""
        if self.validate_inputs():
            config = self.get_config()
            save_config(config)
            
            msg = f"""✅ Configuration saved!

Server: {config['server_ip']}:{config['server_port']}
Device: {config['device_name']}
Type: {config['system_type'].title()}
Idle Threshold: {config['idle_threshold']}s
Grace Period: {config['grace_period']}s
Heartbeat Interval: {config['heartbeat_interval']}s

Agent will start monitoring..."""
            
            QMessageBox.information(self, "Starting Agent", msg)
            self.close()
            
            # Start the agent silently (no console window)
            agent_path = Path(__file__).parent / "agent.py"
            if os.name == 'nt':
                # Use pythonw.exe for windowless execution
                pythonw = Path(sys.executable).parent / "pythonw.exe"
                if pythonw.exists():
                    subprocess.Popen([str(pythonw), str(agent_path)], 
                                   creationflags=subprocess.CREATE_NO_WINDOW)
                else:
                    subprocess.Popen([sys.executable, str(agent_path)], 
                                   creationflags=subprocess.CREATE_NO_WINDOW)
            else:
                subprocess.Popen([sys.executable, str(agent_path)])


def main():
    """Main entry point"""
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    # Set dark palette
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(26, 26, 46))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(224, 224, 224))
    palette.setColor(QPalette.ColorRole.Base, QColor(45, 45, 68))
    palette.setColor(QPalette.ColorRole.Text, QColor(255, 255, 255))
    palette.setColor(QPalette.ColorRole.Button, QColor(45, 45, 68))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor(255, 255, 255))
    palette.setColor(QPalette.ColorRole.Highlight, QColor(124, 58, 237))
    app.setPalette(palette)
    
    window = SetupWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
