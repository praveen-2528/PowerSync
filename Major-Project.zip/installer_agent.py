"""
PowerSync - Agent Installer (Lab Computer Client)
For lab computers that need activity monitoring
"""
import os
import sys
import subprocess
import ctypes
import winreg
from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QCheckBox, QProgressBar, QFrame, QMessageBox,
    QLineEdit, QFormLayout, QGroupBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QPalette, QColor
import json

if getattr(sys, 'frozen', False):
    SCRIPT_DIR = Path(sys.executable).parent
else:
    SCRIPT_DIR = Path(__file__).parent

AGENT_DIR = SCRIPT_DIR / "agent"
CONFIG_FILE = AGENT_DIR / "agent_config.json"


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


def run_as_admin():
    if getattr(sys, 'frozen', False):
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, "", None, 1)
    else:
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{__file__}"', None, 1)
    sys.exit()


def get_desktop_path():
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders")
        desktop = winreg.QueryValueEx(key, "Desktop")[0]
        winreg.CloseKey(key)
        return Path(desktop)
    except:
        return Path.home() / "Desktop"


def load_config():
    defaults = {"server_ip": "localhost", "server_port": 8000}
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                return {**defaults, **json.load(f)}
        except:
            pass
    return defaults


def save_config(config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)


class InstallThread(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)
    
    def __init__(self, server_ip, server_port):
        super().__init__()
        self.server_ip = server_ip
        self.server_port = server_port
    
    def run(self):
        try:
            python_exe = sys.executable
            desktop = get_desktop_path()
            
            # Step 1: Save config
            self.progress.emit(20, "Saving configuration...")
            config = load_config()
            config["server_ip"] = self.server_ip
            config["server_port"] = int(self.server_port)
            save_config(config)
            
            # Step 2: Create settings shortcut
            self.progress.emit(40, "Creating Settings shortcut...")
            setup_gui = AGENT_DIR / "setup_gui.py"
            self._create_shortcut(desktop / "PowerSync Settings.lnk", python_exe, f'"{setup_gui}"', str(AGENT_DIR))
            
            # Step 3: Create Task Scheduler entry
            self.progress.emit(60, "Creating auto-start task...")
            agent_script = AGENT_DIR / "agent.py"
            pythonw = python_exe.replace("python.exe", "pythonw.exe")
            self._create_task("PowerSync_Agent", f'"{pythonw}" "{agent_script}"')
            
            # Step 4: Start agent now
            self.progress.emit(80, "Starting agent...")
            subprocess.Popen([pythonw, str(agent_script)], creationflags=subprocess.CREATE_NO_WINDOW)
            
            self.progress.emit(100, "Agent installation completed!")
            self.finished.emit(True, "Agent installed and running!")
        except Exception as e:
            self.finished.emit(False, f"Installation failed: {str(e)}")
    
    def _create_shortcut(self, shortcut_path, target, arguments, work_dir):
        ps_script = f'''
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("{shortcut_path}")
$Shortcut.TargetPath = "{target}"
$Shortcut.Arguments = '{arguments}'
$Shortcut.WorkingDirectory = "{work_dir}"
$Shortcut.Save()
'''
        subprocess.run(["powershell", "-Command", ps_script], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
    
    def _create_task(self, task_name, command):
        cmd = ["schtasks", "/create", "/tn", task_name, "/tr", command, "/sc", "ONLOGON", "/rl", "HIGHEST", "/f"]
        subprocess.run(cmd, capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)


class AgentInstallerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.config = load_config()
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("⚡ PowerSync Agent Installer")
        self.setFixedSize(480, 450)
        self.setStyleSheet("""
            QMainWindow { background-color: #1a1a2e; }
            QWidget { color: #e0e0e0; font-family: 'Segoe UI'; font-size: 10pt; }
            QLabel#header { font-size: 18pt; font-weight: bold; color: #a78bfa; }
            QLabel#subtitle { font-size: 11pt; color: #6b7280; }
            QLineEdit { background: #2d2d44; border: 1px solid #3d3d5c; border-radius: 6px; padding: 10px; color: white; }
            QLineEdit:focus { border: 2px solid #7c3aed; }
            QGroupBox { font-weight: bold; color: #a78bfa; border: 1px solid #3d3d5c; border-radius: 8px; margin-top: 10px; padding: 15px; }
            QGroupBox::title { subcontrol-origin: margin; left: 15px; }
            QProgressBar { height: 25px; background: #2d2d44; border-radius: 12px; }
            QProgressBar::chunk { background: #22c55e; border-radius: 12px; }
            QPushButton { padding: 12px 30px; border-radius: 8px; font-weight: bold; }
            QPushButton#install { background: #22c55e; color: white; border: none; }
            QPushButton#install:hover { background: #16a34a; }
            QPushButton#install:disabled { background: #4b5563; }
            QPushButton#close { background: #374151; color: white; border: none; }
        """)
        
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(15)
        layout.setContentsMargins(30, 25, 30, 25)
        
        header = QLabel("⚡ PowerSync Agent Installer")
        header.setObjectName("header")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(header)
        
        subtitle = QLabel("Lab Computer Monitoring Client")
        subtitle.setObjectName("subtitle")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)
        
        admin_status = "✅ Running as Administrator" if is_admin() else "⚠️ Run as Administrator for auto-start"
        admin_label = QLabel(admin_status)
        admin_label.setStyleSheet(f"color: {'#22c55e' if is_admin() else '#f97316'};")
        admin_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(admin_label)
        
        # Server connection group
        server_group = QGroupBox("🌐 Server Connection")
        server_layout = QFormLayout(server_group)
        
        self.ip_input = QLineEdit(self.config.get("server_ip", "localhost"))
        self.ip_input.setPlaceholderText("Admin server IP address")
        server_layout.addRow("Server IP:", self.ip_input)
        
        self.port_input = QLineEdit(str(self.config.get("server_port", 8000)))
        self.port_input.setPlaceholderText("8000")
        self.port_input.setMaximumWidth(100)
        server_layout.addRow("Port:", self.port_input)
        
        layout.addWidget(server_group)
        
        # What will be installed
        info_label = QLabel("This will:\n• Configure agent to connect to admin server\n• Create Settings shortcut on Desktop\n• Set agent to auto-start at login\n• Start the agent immediately")
        info_label.setStyleSheet("color: #94a3b8; padding: 10px;")
        layout.addWidget(info_label)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.status_label)
        
        btn_layout = QHBoxLayout()
        self.install_btn = QPushButton("🚀  Install Agent")
        self.install_btn.setObjectName("install")
        self.install_btn.clicked.connect(self.start_install)
        btn_layout.addWidget(self.install_btn)
        
        close_btn = QPushButton("Close")
        close_btn.setObjectName("close")
        close_btn.clicked.connect(self.close)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        layout.addStretch()
    
    def start_install(self):
        if not self.ip_input.text().strip():
            QMessageBox.warning(self, "Warning", "Please enter the server IP address!")
            return
        
        self.install_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        
        self.thread = InstallThread(self.ip_input.text().strip(), self.port_input.text().strip())
        self.thread.progress.connect(lambda v, s: (self.progress_bar.setValue(v), self.status_label.setText(s)))
        self.thread.finished.connect(self.install_done)
        self.thread.start()
    
    def install_done(self, success, msg):
        self.install_btn.setEnabled(True)
        self.progress_bar.setValue(100)
        self.status_label.setText(("✅ " if success else "❌ ") + msg)
        if success:
            QMessageBox.information(self, "Success", 
                "Agent installed successfully!\n\n"
                "• Agent is now running in background\n"
                "• Will auto-start on next login\n"
                "• Use 'PowerSync Settings' shortcut to configure")


def main():
    if not is_admin():
        reply = ctypes.windll.user32.MessageBoxW(0, "PowerSync Agent Installer needs Administrator privileges for auto-start.\n\nClick OK to restart as Administrator.", "⚡ PowerSync", 0x31)
        if reply == 1:
            run_as_admin()
    
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(26, 26, 46))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(224, 224, 224))
    app.setPalette(palette)
    
    window = AgentInstallerWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
