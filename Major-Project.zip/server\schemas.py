"""
Pydantic schemas for API request/response validation
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum


class DeviceStatus(str, Enum):
    ACTIVE = "active"
    PASSIVE_IDLE = "passive"
    DEEP_IDLE = "deep_idle"
    OFFLINE = "offline"


class CommandType(str, Enum):
    STAY_AWAKE = "STAY_AWAKE"
    SLEEP = "SLEEP"
    SHUTDOWN = "SHUTDOWN"
    RESTART = "RESTART"
    MESSAGE = "MESSAGE"


# ============ Heartbeat Schemas ============

class HeartbeatRequest(BaseModel):
    """Payload sent by agent every N seconds"""
    device_id: str
    hostname: str
    ip_address: str
    mac_address: str
    idle_seconds: int
    cpu_usage: float
    ram_usage: float
    
    # Optional hardware specs (sent once or when changed)
    os_name: Optional[str] = None
    os_version: Optional[str] = None
    cpu_model: Optional[str] = None
    ram_total_gb: Optional[float] = None
    system_type: Optional[str] = "lab"  # lab, admin, server, personal, network


class HeartbeatResponse(BaseModel):
    """Response containing command for agent"""
    command: CommandType = CommandType.STAY_AWAKE
    message: Optional[str] = None
    grace_period_seconds: int = 60


# ============ Device Schemas ============

class DeviceBase(BaseModel):
    device_id: str
    hostname: str
    ip_address: str
    mac_address: str


class DeviceResponse(DeviceBase):
    id: int
    status: DeviceStatus
    last_heartbeat: Optional[datetime]
    idle_seconds: int
    cpu_usage: float
    
    os_name: Optional[str]
    os_version: Optional[str]
    cpu_model: Optional[str]
    ram_total_gb: Optional[float]
    system_type: Optional[str] = "lab"  # lab, admin, server, personal, network
    
    # Analytics for this device
    total_uptime_minutes: int
    total_idle_minutes: int
    total_powered_off_minutes: int
    
    class Config:
        from_attributes = True


class DeviceDetailResponse(DeviceResponse):
    """Extended device info with recent history"""
    energy_saved_kwh: float = 0.0
    cost_saved_rupees: float = 0.0
    co2_reduced_kg: float = 0.0
    
    recent_cpu_history: List[dict] = []  # [{timestamp, value}]
    recent_idle_history: List[dict] = []


class DeviceListResponse(BaseModel):
    devices: List[DeviceResponse]
    total_count: int
    active_count: int
    idle_count: int
    offline_count: int


# ============ Command Schemas ============

class SendCommandRequest(BaseModel):
    command: CommandType
    message: Optional[str] = None


# ============ Analytics Schemas ============

class AnalyticsResponse(BaseModel):
    """System-wide analytics"""
    total_devices: int
    active_devices: int
    idle_devices: int
    offline_devices: int
    
    total_energy_saved_kwh: float
    total_cost_saved_rupees: float
    total_co2_reduced_kg: float
    
    today_energy_saved_kwh: float
    today_cost_saved_rupees: float
    
    this_month_energy_saved_kwh: float
    this_month_cost_saved_rupees: float


# ============ Settings Schemas ============

class SettingItem(BaseModel):
    key: str
    value: str
    description: str


class SettingsResponse(BaseModel):
    settings: List[SettingItem]


class UpdateSettingRequest(BaseModel):
    key: str
    value: str


# ============ Network Switch Schemas ============

class NetworkSwitchBase(BaseModel):
    name: str
    location: str
    smart_plug_ip: Optional[str] = None
    smart_plug_type: Optional[str] = None
    connected_device_ids: List[str] = []


class NetworkSwitchResponse(NetworkSwitchBase):
    id: int
    is_powered: bool
    
    class Config:
        from_attributes = True
