"""
PowerSync - GUI Installer
PyQt6-based installation wizard with admin elevation
"""
import os
import sys
import subprocess
import ctypes
import winreg
from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QCheckBox, QProgressBar, QTextEdit,
    QFrame, QMessageBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QPalette, QColor

# Paths - Using relative paths from where EXE is located
if getattr(sys, 'frozen', False):
    # Running as compiled EXE
    SCRIPT_DIR = Path(sys.executable).parent
else:
    # Running as script
    SCRIPT_DIR = Path(__file__).parent

AGENT_DIR = SCRIPT_DIR / "agent"
SERVER_DIR = SCRIPT_DIR / "server"
DASHBOARD_DIR = SCRIPT_DIR / "dashboard"


def is_admin():
    """Check if running with admin privileges"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


def run_as_admin():
    """Re-run this script with admin privileges"""
    if getattr(sys, 'frozen', False):
        # Running as EXE
        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable, "", None, 1
        )
    else:
        # Running as script
        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable, f'"{__file__}"', None, 1
        )
    sys.exit()


def get_python_exe():
    """Get Python executable path"""
    return sys.executable


def get_desktop_path():
    """Get user's desktop path"""
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders")
        desktop = winreg.QueryValueEx(key, "Desktop")[0]
        winreg.CloseKey(key)
        return Path(desktop)
    except:
        return Path.home() / "Desktop"


class InstallThread(QThread):
    """Background thread for installation"""
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)
    
    def __init__(self, install_agent, install_server, install_dashboard):
        super().__init__()
        self.install_agent = install_agent
        self.install_server = install_server
        self.install_dashboard = install_dashboard
    
    def run(self):
        try:
            total_steps = sum([self.install_agent, self.install_server, self.install_dashboard]) * 2
            current_step = 0
            python_exe = get_python_exe()
            desktop = get_desktop_path()
            
            if self.install_agent:
                # Create agent shortcut
                current_step += 1
                self.progress.emit(int(current_step / total_steps * 100), 
                                   "Creating Agent settings shortcut...")
                self._create_shortcut(
                    desktop / "PowerSync Settings.lnk",
                    python_exe,
                    f'"{AGENT_DIR / "setup_gui.py"}"',
                    str(AGENT_DIR)
                )
                
                # Create agent task
                current_step += 1
                self.progress.emit(int(current_step / total_steps * 100),
                                   "Creating Agent auto-start task...")
                self._create_task("PowerSync_Agent", 
                                  f'"{python_exe}" "{AGENT_DIR / "agent.py"}"')
            
            if self.install_server:
                # Create server batch file
                current_step += 1
                self.progress.emit(int(current_step / total_steps * 100),
                                   "Creating Server launcher...")
                batch_file = SERVER_DIR / "start_server.bat"
                with open(batch_file, 'w') as f:
                    f.write(f'@echo off\ncd /d "{SERVER_DIR}"\n"{python_exe}" -m uvicorn main:app --host 0.0.0.0 --port 8000\n')
                
                self._create_shortcut(
                    desktop / "PowerSync Server.lnk",
                    str(batch_file),
                    "",
                    str(SERVER_DIR)
                )
                
                # Create server task
                current_step += 1
                self.progress.emit(int(current_step / total_steps * 100),
                                   "Creating Server auto-start task...")
                self._create_task("PowerSync_Server", f'"{batch_file}"')
            
            if self.install_dashboard:
                # Create dashboard batch file
                current_step += 1
                self.progress.emit(int(current_step / total_steps * 100),
                                   "Creating Dashboard launcher...")
                batch_file = DASHBOARD_DIR / "start_dashboard.bat"
                with open(batch_file, 'w') as f:
                    f.write(f'@echo off\ncd /d "{DASHBOARD_DIR}"\nnpm run tauri dev\n')
                
                self._create_shortcut(
                    desktop / "PowerSync Dashboard.lnk",
                    str(batch_file),
                    "",
                    str(DASHBOARD_DIR)
                )
                
                current_step += 1
                self.progress.emit(100, "Dashboard shortcut created!")
            
            self.finished.emit(True, "Installation completed successfully!")
            
        except Exception as e:
            self.finished.emit(False, f"Installation failed: {str(e)}")
    
    def _create_shortcut(self, shortcut_path, target, arguments, work_dir):
        """Create Windows shortcut"""
        ps_script = f'''
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("{shortcut_path}")
$Shortcut.TargetPath = "{target}"
$Shortcut.Arguments = '{arguments}'
$Shortcut.WorkingDirectory = "{work_dir}"
$Shortcut.Save()
'''
        subprocess.run(["powershell", "-Command", ps_script], 
                      capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
    
    def _create_task(self, task_name, command):
        """Create Task Scheduler entry"""
        cmd = [
            "schtasks", "/create", "/tn", task_name,
            "/tr", command,
            "/sc", "ONLOGON",
            "/rl", "HIGHEST",
            "/f"
        ]
        subprocess.run(cmd, capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)


class InstallerWindow(QMainWindow):
    """Main installer window"""
    
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("⚡ PowerSync Installer")
        self.setFixedSize(500, 450)
        self.setStyleSheet(self.get_stylesheet())
        
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(20)
        layout.setContentsMargins(30, 30, 30, 30)
        
        # Header
        header = QLabel("⚡ PowerSync Installer")
        header.setObjectName("header")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(header)
        
        subtitle = QLabel("Smart Power Management System")
        subtitle.setObjectName("subtitle")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)
        
        # Admin status
        if is_admin():
            admin_label = QLabel("✅ Running as Administrator")
            admin_label.setStyleSheet("color: #22c55e; font-size: 10pt;")
        else:
            admin_label = QLabel("⚠️ Not running as Administrator (some features may fail)")
            admin_label.setStyleSheet("color: #f97316; font-size: 10pt;")
        admin_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(admin_label)
        
        # Separator
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("background-color: #3d3d5c;")
        layout.addWidget(line)
        
        # Options
        options_label = QLabel("Select components to install:")
        options_label.setStyleSheet("font-weight: bold; font-size: 11pt;")
        layout.addWidget(options_label)
        
        self.agent_check = QCheckBox("🖥️  Agent (activity monitoring + settings shortcut)")
        self.agent_check.setChecked(True)
        layout.addWidget(self.agent_check)
        
        self.server_check = QCheckBox("🌐  Server (central API + auto-start)")
        self.server_check.setChecked(True)
        layout.addWidget(self.server_check)
        
        self.dashboard_check = QCheckBox("📊  Dashboard (admin panel shortcut)")
        self.dashboard_check.setChecked(True)
        layout.addWidget(self.dashboard_check)
        
        # Progress
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.status_label)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        self.install_btn = QPushButton("🚀  Install")
        self.install_btn.setObjectName("install_btn")
        self.install_btn.setMinimumHeight(45)
        self.install_btn.clicked.connect(self.start_install)
        btn_layout.addWidget(self.install_btn)
        
        self.close_btn = QPushButton("Close")
        self.close_btn.setObjectName("close_btn")
        self.close_btn.setMinimumHeight(45)
        self.close_btn.clicked.connect(self.close)
        btn_layout.addWidget(self.close_btn)
        
        layout.addLayout(btn_layout)
        layout.addStretch()
    
    def get_stylesheet(self):
        return """
            QMainWindow { background-color: #1a1a2e; }
            QWidget { color: #e0e0e0; font-family: 'Segoe UI', Arial; font-size: 10pt; }
            QLabel#header { font-size: 20pt; font-weight: bold; color: #a78bfa; }
            QLabel#subtitle { font-size: 11pt; color: #6b7280; margin-bottom: 10px; }
            QCheckBox { font-size: 10pt; padding: 8px; }
            QCheckBox::indicator { width: 20px; height: 20px; }
            QProgressBar { height: 25px; background: #2d2d44; border-radius: 12px; }
            QProgressBar::chunk { background: #7c3aed; border-radius: 12px; }
            QPushButton { padding: 12px 30px; border-radius: 8px; font-weight: bold; }
            QPushButton#install_btn { background: #7c3aed; color: white; border: none; }
            QPushButton#install_btn:hover { background: #6d28d9; }
            QPushButton#install_btn:disabled { background: #4b5563; }
            QPushButton#close_btn { background: #374151; color: white; border: none; }
            QPushButton#close_btn:hover { background: #4b5563; }
        """
    
    def start_install(self):
        if not any([self.agent_check.isChecked(), 
                    self.server_check.isChecked(), 
                    self.dashboard_check.isChecked()]):
            QMessageBox.warning(self, "Warning", "Please select at least one component!")
            return
        
        self.install_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        
        self.install_thread = InstallThread(
            self.agent_check.isChecked(),
            self.server_check.isChecked(),
            self.dashboard_check.isChecked()
        )
        self.install_thread.progress.connect(self.update_progress)
        self.install_thread.finished.connect(self.install_finished)
        self.install_thread.start()
    
    def update_progress(self, value, status):
        self.progress_bar.setValue(value)
        self.status_label.setText(status)
    
    def install_finished(self, success, message):
        self.install_btn.setEnabled(True)
        self.progress_bar.setValue(100)
        
        if success:
            self.status_label.setText("✅ " + message)
            QMessageBox.information(self, "Success", 
                "Installation completed!\n\n"
                "• Desktop shortcuts have been created\n"
                "• Auto-start tasks have been configured\n\n"
                "The agent and server will start automatically at next login.")
        else:
            self.status_label.setText("❌ " + message)
            QMessageBox.critical(self, "Error", message)


def main():
    # Request admin if not already
    if not is_admin():
        reply = ctypes.windll.user32.MessageBoxW(
            0,
            "PowerSync Installer needs Administrator privileges to:\n"
            "• Create Task Scheduler entries\n"
            "• Set up auto-start\n\n"
            "Click OK to restart as Administrator.",
            "⚡ PowerSync Installer",
            0x31  # MB_OKCANCEL | MB_ICONWARNING
        )
        if reply == 1:  # OK
            run_as_admin()
        # Continue anyway if user cancels
    
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(26, 26, 46))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(224, 224, 224))
    app.setPalette(palette)
    
    window = InstallerWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
