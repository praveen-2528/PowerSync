"""
Scheduler service for automated power management rules
"""
from datetime import datetime, time
from sqlalchemy.orm import Session
from models import Device, Settings, PowerEvent
from schemas import CommandType


def get_setting_value(db: Session, key: str, default: str = "") -> str:
    """Get a setting value"""
    setting = db.query(Settings).filter(Settings.key == key).first()
    return setting.value if setting else default


def parse_time(time_str: str) -> time:
    """Parse time string (HH:MM) to time object"""
    parts = time_str.split(":")
    return time(int(parts[0]), int(parts[1]))


def is_working_hours(db: Session) -> bool:
    """Check if current time is within working hours"""
    now = datetime.now().time()
    
    start_str = get_setting_value(db, "working_hours_start", "09:00")
    end_str = get_setting_value(db, "working_hours_end", "17:00")
    
    start_time = parse_time(start_str)
    end_time = parse_time(end_str)
    
    return start_time <= now <= end_time


def determine_command_for_device(db: Session, device: Device) -> tuple[CommandType, str]:
    """
    Determine what command to send to a device based on its idle time.
    Maximum 3 minutes (180s) idle threshold for aggressive power optimization.
    
    Returns:
        tuple: (CommandType, message/reason)
    """
    idle_seconds = device.idle_seconds
    
    # Get threshold - capped at 180 seconds (3 minutes) for maximum optimization
    working_hours_threshold = min(int(get_setting_value(db, "working_hours_idle_threshold", "180")), 180)
    after_hours_threshold = min(int(get_setting_value(db, "after_hours_idle_threshold", "180")), 180)
    
    is_working = is_working_hours(db)
    
    if is_working:
        # During working hours: Use SLEEP after 3 mins max (allows faster wake-up)
        if idle_seconds >= working_hours_threshold:
            return CommandType.SLEEP, f"System idle for {idle_seconds//60}+ mins. Entering sleep mode to save energy."
    else:
        # After hours: Full shutdown after 3 mins max
        if idle_seconds >= after_hours_threshold:
            return CommandType.SHUTDOWN, f"System idle for {idle_seconds//60}+ mins after hours. Shutting down."
    
    # Default: Stay awake
    return CommandType.STAY_AWAKE, ""


def update_device_status(db: Session, device: Device, idle_seconds: int) -> str:
    """
    Update device status based on idle time
    
    Returns:
        str: New status
    """
    passive_threshold = int(get_setting_value(db, "idle_threshold_passive", "300"))
    deep_threshold = int(get_setting_value(db, "idle_threshold_deep", "1200"))
    
    if idle_seconds < 60:
        return "active"
    elif idle_seconds < passive_threshold:
        return "active"  # Still considered active if < 5 mins
    elif idle_seconds < deep_threshold:
        return "passive"
    else:
        return "deep_idle"


def log_power_event(db: Session, device_id: int, event_type: str, triggered_by: str = "auto"):
    """Log a power event for analytics"""
    event = PowerEvent(
        device_id=device_id,
        event_type=event_type,
        triggered_by=triggered_by
    )
    db.add(event)
    db.commit()


def check_all_devices_for_switch(db: Session, connected_device_ids: list[str]) -> bool:
    """
    Check if all connected devices are offline/idle
    Used for network switch dependency logic
    
    Returns:
        bool: True if switch can be powered off (all devices offline/idle)
    """
    if not connected_device_ids:
        return False
    
    devices = db.query(Device).filter(Device.device_id.in_(connected_device_ids)).all()
    
    if not devices:
        return False
    
    # Check if ALL devices are offline or deep_idle
    for device in devices:
        if device.status in ["active", "passive"]:
            return False  # At least one device is in use
    
    return True
