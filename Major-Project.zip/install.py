"""
PowerSync - Installer Script
Creates Task Scheduler entries and desktop shortcuts for Agent and Server
Run with administrator privileges for best results
"""
import os
import sys
import subprocess
import winreg
from pathlib import Path

# Paths
SCRIPT_DIR = Path(__file__).parent
AGENT_DIR = SCRIPT_DIR / "agent"
SERVER_DIR = SCRIPT_DIR / "server"
PYTHON_EXE = sys.executable
PYTHONW_EXE = PYTHON_EXE.replace("python.exe", "pythonw.exe")

# Task names
AGENT_TASK_NAME = "PowerSync_Agent"
SERVER_TASK_NAME = "PowerSync_Server"


def get_desktop_path():
    """Get the user's desktop path"""
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 
                             r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders")
        desktop = winreg.QueryValueEx(key, "Desktop")[0]
        winreg.CloseKey(key)
        return Path(desktop)
    except:
        return Path.home() / "Desktop"


def create_shortcut(name, target, arguments, icon_path=None, work_dir=None):
    """Create a Windows shortcut (.lnk file)"""
    desktop = get_desktop_path()
    shortcut_path = desktop / f"{name}.lnk"
    
    # Use PowerShell to create shortcut
    ps_script = f'''
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("{shortcut_path}")
$Shortcut.TargetPath = "{target}"
$Shortcut.Arguments = "{arguments}"
$Shortcut.WorkingDirectory = "{work_dir or ''}"
$Shortcut.Save()
'''
    
    try:
        subprocess.run(["powershell", "-Command", ps_script], 
                      capture_output=True, check=True)
        print(f"✅ Created shortcut: {shortcut_path}")
        return True
    except Exception as e:
        print(f"❌ Failed to create shortcut: {e}")
        return False


def create_task_scheduler_entry(task_name, python_script, work_dir, trigger="ONLOGON", hidden=True):
    """Create a Windows Task Scheduler entry"""
    
    exe = PYTHONW_EXE if hidden else PYTHON_EXE
    
    # Build the schtasks command
    cmd = [
        "schtasks", "/create", "/tn", task_name,
        "/tr", f'"{exe}" "{python_script}"',
        "/sc", trigger,
        "/rl", "HIGHEST",  # Run with highest privileges
        "/f"  # Force overwrite if exists
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ Created Task Scheduler entry: {task_name}")
            return True
        else:
            print(f"⚠️ Task creation warning: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ Failed to create task: {e}")
        return False


def delete_task_scheduler_entry(task_name):
    """Delete a Task Scheduler entry"""
    try:
        subprocess.run(["schtasks", "/delete", "/tn", task_name, "/f"], 
                      capture_output=True)
        print(f"🗑️ Removed task: {task_name}")
    except:
        pass


def install_agent():
    """Install agent with auto-start and shortcuts"""
    print("\n📦 Installing PowerSync Agent...")
    
    agent_script = AGENT_DIR / "agent.py"
    setup_gui_script = AGENT_DIR / "setup_gui.py"
    
    if not agent_script.exists():
        print(f"❌ Agent script not found: {agent_script}")
        return False
    
    # Create Task Scheduler entry for agent (runs at user login)
    create_task_scheduler_entry(
        AGENT_TASK_NAME,
        str(agent_script),
        str(AGENT_DIR),
        trigger="ONLOGON",
        hidden=True  # Run silently
    )
    
    # Create desktop shortcut for settings GUI
    create_shortcut(
        "PowerSync Settings",
        PYTHON_EXE,
        f'"{setup_gui_script}"',
        work_dir=str(AGENT_DIR)
    )
    
    print("✅ Agent installation complete!")
    return True


def install_server():
    """Install server with auto-start"""
    print("\n📦 Installing PowerSync Server...")
    
    server_script = SERVER_DIR / "main.py"
    
    if not server_script.exists():
        print(f"❌ Server script not found: {server_script}")
        return False
    
    # Create a batch file to start server with uvicorn
    batch_file = SERVER_DIR / "start_server.bat"
    batch_content = f'''@echo off
cd /d "{SERVER_DIR}"
"{PYTHON_EXE}" -m uvicorn main:app --host 0.0.0.0 --port 8000
'''
    
    with open(batch_file, 'w') as f:
        f.write(batch_content)
    
    # Create Task Scheduler entry for server (runs at system startup)
    # Using ONSTART requires admin privileges
    cmd = [
        "schtasks", "/create", "/tn", SERVER_TASK_NAME,
        "/tr", f'"{batch_file}"',
        "/sc", "ONLOGON",
        "/rl", "HIGHEST",
        "/f"
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ Created Task Scheduler entry: {SERVER_TASK_NAME}")
        else:
            print(f"⚠️ {result.stderr}")
    except Exception as e:
        print(f"❌ Failed: {e}")
    
    # Create desktop shortcut for server
    create_shortcut(
        "PowerSync Server",
        str(batch_file),
        "",
        work_dir=str(SERVER_DIR)
    )
    
    print("✅ Server installation complete!")
    return True


def install_dashboard():
    """Create shortcut for dashboard"""
    print("\n📦 Creating Dashboard shortcut...")
    
    dashboard_dir = SCRIPT_DIR / "dashboard"
    
    # Create a batch file to start dashboard
    batch_file = dashboard_dir / "start_dashboard.bat"
    batch_content = f'''@echo off
cd /d "{dashboard_dir}"
npm run tauri dev
'''
    
    with open(batch_file, 'w') as f:
        f.write(batch_content)
    
    create_shortcut(
        "PowerSync Dashboard",
        str(batch_file),
        "",
        work_dir=str(dashboard_dir)
    )
    
    print("✅ Dashboard shortcut created!")
    return True


def uninstall():
    """Remove all Task Scheduler entries"""
    print("\n🗑️ Uninstalling PowerSync...")
    delete_task_scheduler_entry(AGENT_TASK_NAME)
    delete_task_scheduler_entry(SERVER_TASK_NAME)
    print("✅ Uninstallation complete!")


def main():
    # Check for command line arguments
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower()
        if arg in ['--all', '-a', '4']:
            install_agent()
            install_server()
            install_dashboard()
        elif arg in ['--agent', '-g', '1']:
            install_agent()
        elif arg in ['--server', '-s', '2']:
            install_server()
        elif arg in ['--dashboard', '-d', '3']:
            install_dashboard()
        elif arg in ['--uninstall', '-u', '5']:
            uninstall()
        elif arg in ['--help', '-h']:
            print("Usage: python install.py [OPTION]")
            print("  --all, -a      Install all components")
            print("  --agent, -g    Install agent only")
            print("  --server, -s   Install server only")
            print("  --dashboard, -d Install dashboard shortcut")
            print("  --uninstall, -u Remove auto-start entries")
        return
    
    print("""
╔══════════════════════════════════════════════════════╗
║         PowerSync - Installation Wizard              ║
╠══════════════════════════════════════════════════════╣
║   1. Install Agent (auto-start + settings shortcut)  ║
║   2. Install Server (auto-start)                     ║
║   3. Install Dashboard shortcut                      ║
║   4. Install ALL                                     ║
║   5. Uninstall (remove auto-start)                   ║
║   0. Exit                                            ║
╚══════════════════════════════════════════════════════╝
    """)
    
    try:
        choice = input("Enter your choice (0-5): ").strip()
    except EOFError:
        choice = "0"
    
    if choice == "1":
        install_agent()
    elif choice == "2":
        install_server()
    elif choice == "3":
        install_dashboard()
    elif choice == "4":
        install_agent()
        install_server()
        install_dashboard()
    elif choice == "5":
        uninstall()
    elif choice == "0":
        print("👋 Goodbye!")
    else:
        print("❌ Invalid choice")
    
    try:
        input("\nPress Enter to exit...")
    except EOFError:
        pass


if __name__ == "__main__":
    main()
