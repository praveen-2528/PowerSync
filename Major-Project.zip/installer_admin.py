"""
PowerSync - Admin Installer (Server + Dashboard)
For the administrator machine only
"""
import os
import sys
import subprocess
import ctypes
import winreg
from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QCheckBox, QProgressBar, QFrame, QMessageBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QPalette, QColor

if getattr(sys, 'frozen', False):
    SCRIPT_DIR = Path(sys.executable).parent
else:
    SCRIPT_DIR = Path(__file__).parent

SERVER_DIR = SCRIPT_DIR / "server"
DASHBOARD_DIR = SCRIPT_DIR / "dashboard"


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


def run_as_admin():
    if getattr(sys, 'frozen', False):
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, "", None, 1)
    else:
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{__file__}"', None, 1)
    sys.exit()


def get_desktop_path():
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders")
        desktop = winreg.QueryValueEx(key, "Desktop")[0]
        winreg.CloseKey(key)
        return Path(desktop)
    except:
        return Path.home() / "Desktop"


class InstallThread(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)
    
    def __init__(self, install_server, install_dashboard):
        super().__init__()
        self.install_server = install_server
        self.install_dashboard = install_dashboard
    
    def run(self):
        try:
            python_exe = sys.executable
            desktop = get_desktop_path()
            steps = sum([self.install_server, self.install_dashboard]) * 2
            current = 0
            
            if self.install_server:
                current += 1
                self.progress.emit(int(current/steps*100), "Creating Server launcher...")
                
                batch_file = SERVER_DIR / "start_server.bat"
                with open(batch_file, 'w') as f:
                    f.write(f'@echo off\ncd /d "{SERVER_DIR}"\n"{python_exe}" -m uvicorn main:app --host 0.0.0.0 --port 8000\n')
                
                self._create_shortcut(desktop / "PowerSync Server.lnk", str(batch_file), "", str(SERVER_DIR))
                
                current += 1
                self.progress.emit(int(current/steps*100), "Creating Server auto-start task...")
                self._create_task("PowerSync_Server", f'"{batch_file}"')
            
            if self.install_dashboard:
                current += 1
                self.progress.emit(int(current/steps*100), "Creating Dashboard launcher...")
                
                batch_file = DASHBOARD_DIR / "start_dashboard.bat"
                with open(batch_file, 'w') as f:
                    f.write(f'@echo off\ncd /d "{DASHBOARD_DIR}"\nnpm run tauri dev\n')
                
                self._create_shortcut(desktop / "PowerSync Dashboard.lnk", str(batch_file), "", str(DASHBOARD_DIR))
                
                current += 1
                self.progress.emit(100, "Dashboard shortcut created!")
            
            self.finished.emit(True, "Admin installation completed!")
        except Exception as e:
            self.finished.emit(False, f"Installation failed: {str(e)}")
    
    def _create_shortcut(self, shortcut_path, target, arguments, work_dir):
        ps_script = f'''
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("{shortcut_path}")
$Shortcut.TargetPath = "{target}"
$Shortcut.Arguments = '{arguments}'
$Shortcut.WorkingDirectory = "{work_dir}"
$Shortcut.Save()
'''
        subprocess.run(["powershell", "-Command", ps_script], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
    
    def _create_task(self, task_name, command):
        cmd = ["schtasks", "/create", "/tn", task_name, "/tr", command, "/sc", "ONLOGON", "/rl", "HIGHEST", "/f"]
        subprocess.run(cmd, capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)


class AdminInstallerWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("⚡ PowerSync Admin Installer")
        self.setFixedSize(480, 400)
        self.setStyleSheet("""
            QMainWindow { background-color: #1a1a2e; }
            QWidget { color: #e0e0e0; font-family: 'Segoe UI'; font-size: 10pt; }
            QLabel#header { font-size: 18pt; font-weight: bold; color: #a78bfa; }
            QLabel#subtitle { font-size: 11pt; color: #6b7280; }
            QCheckBox { font-size: 10pt; padding: 8px; }
            QProgressBar { height: 25px; background: #2d2d44; border-radius: 12px; }
            QProgressBar::chunk { background: #7c3aed; border-radius: 12px; }
            QPushButton { padding: 12px 30px; border-radius: 8px; font-weight: bold; }
            QPushButton#install { background: #7c3aed; color: white; border: none; }
            QPushButton#install:hover { background: #6d28d9; }
            QPushButton#install:disabled { background: #4b5563; }
            QPushButton#close { background: #374151; color: white; border: none; }
        """)
        
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(15)
        layout.setContentsMargins(30, 30, 30, 30)
        
        header = QLabel("⚡ PowerSync Admin Installer")
        header.setObjectName("header")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(header)
        
        subtitle = QLabel("Server & Dashboard Installation")
        subtitle.setObjectName("subtitle")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)
        
        admin_status = "✅ Running as Administrator" if is_admin() else "⚠️ Run as Administrator for full features"
        admin_label = QLabel(admin_status)
        admin_label.setStyleSheet(f"color: {'#22c55e' if is_admin() else '#f97316'};")
        admin_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(admin_label)
        
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("background-color: #3d3d5c;")
        layout.addWidget(line)
        
        self.server_check = QCheckBox("🌐  Server (Central API + Auto-start)")
        self.server_check.setChecked(True)
        layout.addWidget(self.server_check)
        
        self.dashboard_check = QCheckBox("📊  Dashboard (Admin Control Panel)")
        self.dashboard_check.setChecked(True)
        layout.addWidget(self.dashboard_check)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.status_label)
        
        btn_layout = QHBoxLayout()
        self.install_btn = QPushButton("🚀  Install")
        self.install_btn.setObjectName("install")
        self.install_btn.clicked.connect(self.start_install)
        btn_layout.addWidget(self.install_btn)
        
        close_btn = QPushButton("Close")
        close_btn.setObjectName("close")
        close_btn.clicked.connect(self.close)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        layout.addStretch()
    
    def start_install(self):
        if not any([self.server_check.isChecked(), self.dashboard_check.isChecked()]):
            QMessageBox.warning(self, "Warning", "Select at least one component!")
            return
        
        self.install_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        
        self.thread = InstallThread(self.server_check.isChecked(), self.dashboard_check.isChecked())
        self.thread.progress.connect(lambda v, s: (self.progress_bar.setValue(v), self.status_label.setText(s)))
        self.thread.finished.connect(self.install_done)
        self.thread.start()
    
    def install_done(self, success, msg):
        self.install_btn.setEnabled(True)
        self.progress_bar.setValue(100)
        self.status_label.setText(("✅ " if success else "❌ ") + msg)
        if success:
            QMessageBox.information(self, "Success", "Admin installation completed!\n\n• Desktop shortcuts created\n• Server auto-start configured")


def main():
    if not is_admin():
        reply = ctypes.windll.user32.MessageBoxW(0, "PowerSync Admin Installer needs Administrator privileges.\n\nClick OK to restart as Administrator.", "⚡ PowerSync", 0x31)
        if reply == 1:
            run_as_admin()
    
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(26, 26, 46))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(224, 224, 224))
    app.setPalette(palette)
    
    window = AdminInstallerWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
